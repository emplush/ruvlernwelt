import { verifyAuth } from '@/lib/auth';
import { redirect } from 'next/navigation';

export const dynamic = "force-dynamic";

export default async function Home() {
  const isAuth = await verifyAuth();
  if (isAuth) {
    redirect('/personas');
  } else {
    redirect('/login');
  }
}
