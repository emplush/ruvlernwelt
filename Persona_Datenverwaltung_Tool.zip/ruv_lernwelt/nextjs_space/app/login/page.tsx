import { verifyAuth } from '@/lib/auth';
import { redirect } from 'next/navigation';
import Image from 'next/image';
import LoginForm from './login-form';

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const isAuth = await verifyAuth();
  if (isAuth) redirect('/personas');

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#001957] to-[#00113f]">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center bg-white rounded-xl px-6 py-4 mb-5 shadow-lg">
            <Image
              src="/ruv-logo.png"
              alt="R+V Logo"
              width={120}
              height={79}
              className="h-12 w-auto"
              priority
            />
          </div>
          <h1 className="text-2xl font-bold text-white">Lernwelt</h1>
          <p className="text-white/70 mt-1">Persona-Datenbank</p>
        </div>
        <LoginForm />
      </div>
    </div>
  );
}
