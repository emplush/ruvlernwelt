'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Lock } from 'lucide-react';

export default function LoginForm() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (res.ok) {
        router.push('/personas');
        router.refresh();
      } else {
        setError(data?.error ?? 'Falsches Passwort');
      }
    } catch {
      setError('Verbindungsfehler');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-xl p-8">
      <label htmlFor="password" className="block text-sm font-medium text-[#001957] mb-2">
        Passwort
      </label>
      <div className="relative mb-4">
        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#001957] focus:border-transparent text-[#001957]"
          placeholder="Passwort eingeben"
          autoFocus
        />
      </div>
      {error && <p className="text-[#001957] text-sm mb-4">{error}</p>}
      <button
        type="submit"
        disabled={loading}
        className="w-full py-3 bg-[#001957] hover:bg-[#00113f] text-white font-semibold rounded-lg transition-colors disabled:opacity-50"
      >
        {loading ? 'Anmelden…' : 'Anmelden'}
      </button>
    </form>
  );
}
