'use client';

import { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { Plus, BookOpen, Film, Headphones, Monitor, Trash2, Edit, Search, Filter, X } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

interface Format {
  id: number;
  formatId: number | null;
  name: string;
  formatTyp: string;
  medienentwickler: string;
  personas: { persona: { id: number; vorname: string; name: string } }[];
}

const typeIcon: Record<string, React.ReactNode> = {
  Lernprogramm: <Monitor className="w-4 h-4" />,
  Video: <Film className="w-4 h-4" />,
  Podcast: <Headphones className="w-4 h-4" />,
};

const FORMAT_TYPES = ['Lernprogramm', 'Video', 'Podcast'];

export default function FormateList() {
  const [formate, setFormate] = useState<Format[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [search, setSearch] = useState('');
  const [typFilter, setTypFilter] = useState('');
  const [showFilter, setShowFilter] = useState(false);

  const fetchFormate = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/formate');
      const data = await res.json();
      setFormate(Array.isArray(data) ? data : []);
    } catch {
      setFormate([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchFormate(); }, []);

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch(`/api/formate/${deleteId}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Format gelöscht');
        fetchFormate();
      } else {
        toast.error('Fehler beim Löschen');
      }
    } catch {
      toast.error('Fehler');
    } finally {
      setDeleteId(null);
    }
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (formate ?? []).filter((f) => {
      if (typFilter && f.formatTyp !== typFilter) return false;
      if (!q) return true;
      return (f.name ?? '').toLowerCase().includes(q) ||
        (f.medienentwickler ?? '').toLowerCase().includes(q);
    });
  }, [formate, search, typFilter]);

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#001957] flex items-center gap-2">
            <BookOpen className="w-6 h-6" /> E-Learning-Formate
          </h1>
          <p className="text-sm text-gray-500 mt-1">{filtered?.length ?? 0} von {formate?.length ?? 0} Formaten</p>
        </div>
        <Link
          href="/formate/neu"
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg font-medium text-sm transition-colors shadow-sm"
        >
          <Plus className="w-4 h-4" /> Neues Format
        </Link>
      </div>

      {/* Suche & Filter */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Suche nach Name oder Mediengestalter…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
          />
        </div>
        <div className="relative">
          <button
            onClick={() => setShowFilter(!showFilter)}
            className={`inline-flex items-center gap-2 px-4 py-2.5 border rounded-lg text-sm font-medium transition-colors ${
              typFilter
                ? 'bg-[#001957] text-white border-[#001957]'
                : 'bg-white text-[#001957] border-gray-200 hover:bg-gray-50'
            }`}
          >
            <Filter className="w-4 h-4" />
            {typFilter || 'Format'}
            {typFilter && (
              <X
                className="w-3 h-3 ml-1"
                onClick={(e) => { e.stopPropagation(); setTypFilter(''); }}
              />
            )}
          </button>
          {showFilter && (
            <div className="absolute right-0 mt-1 w-56 bg-white border border-gray-200 rounded-lg shadow-lg z-20 py-1">
              <button
                onClick={() => { setTypFilter(''); setShowFilter(false); }}
                className="w-full text-left px-4 py-2 text-sm text-gray-500 hover:bg-gray-50"
              >
                Alle Formate
              </button>
              {FORMAT_TYPES.map((t) => (
                <button
                  key={t}
                  onClick={() => { setTypFilter(t); setShowFilter(false); }}
                  className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 flex items-center gap-2 ${
                    typFilter === t ? 'text-[#001957] font-medium' : 'text-[#001957]'
                  }`}
                >
                  {typeIcon[t]} {t}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-3 border-[#001957] border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (filtered?.length ?? 0) === 0 ? (
        <div className="text-center py-20 text-gray-400">
          <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Keine E-Learning-Formate gefunden</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence mode="popLayout">
            {(filtered ?? []).map((f, i) => (
              <motion.div
                key={f.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ delay: Math.min(i * 0.03, 0.4) }}
                className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-lg transition-shadow flex flex-col h-full"
              >
                <div className="flex items-start justify-between gap-2">
                  <Link href={`/formate/${f.id}`} className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-[#001957]">{typeIcon[f.formatTyp] ?? <BookOpen className="w-4 h-4" />}</span>
                      <h3 className="font-semibold text-[#001957] truncate">{f.name}</h3>
                    </div>
                  </Link>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <Link href={`/formate/${f.id}/bearbeiten`} className="p-1.5 text-gray-400 hover:text-[#001957] transition-colors">
                      <Edit className="w-4 h-4" />
                    </Link>
                    <button onClick={() => setDeleteId(f.id)} className="p-1.5 text-gray-400 hover:text-[#001957] transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <Link href={`/formate/${f.id}`} className="block space-y-1.5 mt-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-gray-400 uppercase tracking-wide">ID</span>
                    <span className="font-medium text-[#001957]">{f.formatId != null ? String(f.formatId).padStart(3, '0') : '–'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-gray-400 uppercase tracking-wide">Format</span>
                    <span className="font-medium text-[#001957]">{f.formatTyp}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-gray-400 uppercase tracking-wide">Mediengestalter</span>
                    <span className="font-medium text-[#001957] truncate">{f.medienentwickler || '–'}</span>
                  </div>
                </Link>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Delete Dialog */}
      {deleteId && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <h3 className="text-lg font-bold text-[#001957] mb-2">Format löschen?</h3>
            <p className="text-sm text-gray-500 mb-6">Diese Aktion kann nicht rückgängig gemacht werden.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteId(null)} className="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium text-[#001957] hover:bg-gray-50">Abbrechen</button>
              <button onClick={handleDelete} className="px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium">Löschen</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
