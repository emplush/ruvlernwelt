import FormateList from './formate-list';

export const dynamic = "force-dynamic";

export default function FormatePage() {
  return <FormateList />;
}
