'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Edit, Trash2, BookOpen, User, Film, Headphones, Monitor, ExternalLink, FolderOpen, Copy } from 'lucide-react';
import { toast } from 'sonner';

function toExplorerUrl(raw: string): string {
  const p = (raw ?? '').trim();
  if (!p) return p;
  if (/^(file:|https?:)/i.test(p)) return p;
  // UNC-Pfad \\server\share\ordner
  if (p.startsWith('\\')) {
    return 'file://' + p.slice(2).replace(/\\/g, '/');
  }
  // Laufwerkspfad C:\ordner
  if (/^[a-zA-Z]:[\\/]/.test(p)) {
    return 'file:///' + p.replace(/\\/g, '/');
  }
  return p;
}

interface FormatData {
  id: number;
  formatId: number | null;
  link: string | null;
  httpLink: string | null;
  name: string;
  formatTyp: string;
  medienentwickler: string;
  personas: { persona: { id: number; vorname: string; name: string; funktion: string | null } }[];
}

const typeIcon: Record<string, React.ReactNode> = {
  Lernprogramm: <Monitor className="w-5 h-5" />,
  Video: <Film className="w-5 h-5" />,
  Podcast: <Headphones className="w-5 h-5" />,
};

export default function FormatDetail({ id }: { id: string }) {
  const [format, setFormat] = useState<FormatData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showDelete, setShowDelete] = useState(false);
  const router = useRouter();

  useEffect(() => {
    fetch(`/api/formate/${id}`)
      .then((r) => r.json())
      .then((d) => setFormat(d))
      .catch(() => toast.error('Fehler beim Laden'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleDelete = async () => {
    try {
      const res = await fetch(`/api/formate/${id}`, { method: 'DELETE' });
      if (res.ok) { toast.success('Format gelöscht'); router.push('/formate'); }
      else toast.error('Fehler');
    } catch { toast.error('Fehler'); }
  };

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="w-8 h-8 border-3 border-[#001957] border-t-transparent rounded-full animate-spin" /></div>;
  }
  if (!format) {
    return <div className="text-center py-20 text-gray-400"><p>Format nicht gefunden</p></div>;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <Link href="/formate" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-[#001957]">
          <ArrowLeft className="w-4 h-4" /> Zurück
        </Link>
        <div className="flex items-center gap-2">
          <Link href={`/formate/${id}/bearbeiten`} className="inline-flex items-center gap-2 px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium">
            <Edit className="w-4 h-4" /> Bearbeiten
          </Link>
          <button onClick={() => setShowDelete(true)} className="inline-flex items-center gap-2 px-4 py-2 border border-red-200 text-[#001957] hover:bg-red-50 rounded-lg text-sm font-medium">
            <Trash2 className="w-4 h-4" /> Löschen
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-[#001957]">{typeIcon[format.formatTyp] ?? <BookOpen className="w-5 h-5" />}</span>
          <h1 className="text-2xl font-bold text-[#001957]">{format.name}</h1>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div><dt className="text-xs font-medium text-gray-500 uppercase">ID</dt><dd className="text-sm text-[#001957] mt-0.5">{format.formatId != null ? String(format.formatId).padStart(3, '0') : '–'}</dd></div>
          <div><dt className="text-xs font-medium text-gray-500 uppercase">Format-Typ</dt><dd className="text-sm text-[#001957] mt-0.5">{format.formatTyp}</dd></div>
          <div><dt className="text-xs font-medium text-gray-500 uppercase">Medienentwickler</dt><dd className="text-sm text-[#001957] mt-0.5">{format.medienentwickler}</dd></div>
          <div><dt className="text-xs font-medium text-gray-500 uppercase">Personas</dt><dd className="text-sm text-[#001957] mt-0.5">{format.personas?.length ?? 0} zugewiesen</dd></div>
          <div className="sm:col-span-3">
            <dt className="text-xs font-medium text-gray-500 uppercase">Datei-Link</dt>
            <dd className="text-sm mt-1">
              {format.link ? (
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center gap-3">
                    <a href={toExplorerUrl(format.link)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm font-medium text-[#001957] hover:underline">
                      <FolderOpen className="w-4 h-4" /> Im Explorer öffnen
                    </a>
                    <button type="button" onClick={() => { navigator.clipboard?.writeText(format.link ?? '').then(() => toast.success('Pfad kopiert')).catch(() => toast.error('Kopieren nicht möglich')); }} className="inline-flex items-center gap-2 text-sm text-[#109DA8] hover:text-[#001957] hover:underline">
                      <Copy className="w-4 h-4" /> Pfad kopieren
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 break-all">{format.link}</p>
                  <p className="text-xs text-gray-400">Hinweis: Aus Sicherheitsgründen können Browser lokale Ordner nicht immer direkt öffnen. Falls sich der Explorer nicht öffnet, kopieren Sie den Pfad und fügen ihn in die Adresszeile des Windows-Explorers ein.</p>
                </div>
              ) : <span className="text-[#001957]">–</span>}
            </dd>
          </div>
          <div className="sm:col-span-3">
            <dt className="text-xs font-medium text-gray-500 uppercase">HTTP-Link</dt>
            <dd className="text-sm mt-1">
              {format.httpLink ? (
                <a href={format.httpLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-[#109DA8] hover:text-[#001957] hover:underline break-all">
                  <ExternalLink className="w-4 h-4 flex-shrink-0" /> {format.httpLink}
                </a>
              ) : <span className="text-[#001957]">–</span>}
            </dd>
          </div>
        </div>
      </div>

      {(format.personas?.length ?? 0) > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-bold text-[#001957] mb-4">Zugewiesene Personas</h2>
          <div className="space-y-2">
            {(format.personas ?? []).map((fp) => (
              <Link
                key={fp.persona.id}
                href={`/personas/${fp.persona.id}`}
                className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <User className="w-4 h-4 text-gray-400" />
                <div>
                  <p className="font-medium text-sm text-[#001957]">{fp.persona.vorname} {fp.persona.name}</p>
                  {fp.persona.funktion && <p className="text-xs text-gray-500">{fp.persona.funktion}</p>}
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {showDelete && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <h3 className="text-lg font-bold text-[#001957] mb-2">Format löschen?</h3>
            <p className="text-sm text-gray-500 mb-6">Diese Aktion kann nicht rückgängig gemacht werden.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setShowDelete(false)} className="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium text-[#001957] hover:bg-gray-50">Abbrechen</button>
              <button onClick={handleDelete} className="px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium">Löschen</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
