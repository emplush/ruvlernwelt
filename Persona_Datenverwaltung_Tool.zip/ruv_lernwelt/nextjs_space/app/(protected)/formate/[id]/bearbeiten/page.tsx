import FormatForm from '@/components/format-form';

export const dynamic = "force-dynamic";

export default async function BearbeitenFormatPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <FormatForm formatId={id} />;
}
