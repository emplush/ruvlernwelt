import FormatDetail from './format-detail';

export const dynamic = "force-dynamic";

export default async function FormatPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <FormatDetail id={id} />;
}
