import FormatForm from '@/components/format-form';

export const dynamic = "force-dynamic";

export default function NeuesFormatPage() {
  return <FormatForm />;
}
