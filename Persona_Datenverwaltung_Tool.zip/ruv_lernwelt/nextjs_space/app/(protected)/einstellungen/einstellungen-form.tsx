'use client';

import { useState, useEffect } from 'react';
import { Settings, Save, Lock, Type } from 'lucide-react';
import { toast } from 'sonner';

export default function EinstellungenForm() {
  const [appTitle, setAppTitle] = useState('');
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [savingTitle, setSavingTitle] = useState(false);
  const [savingPw, setSavingPw] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/settings')
      .then((r) => r.json())
      .then((d) => setAppTitle(d?.appTitle ?? ''))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const saveTitle = async () => {
    if (!appTitle.trim()) { toast.error('Titel darf nicht leer sein'); return; }
    setSavingTitle(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appTitle }),
      });
      if (res.ok) toast.success('Titel gespeichert');
      else toast.error('Fehler beim Speichern');
    } catch { toast.error('Fehler'); }
    finally { setSavingTitle(false); }
  };

  const savePassword = async () => {
    if (!oldPassword) { toast.error('Bitte altes Passwort eingeben'); return; }
    if (!newPassword) { toast.error('Bitte neues Passwort eingeben'); return; }
    if (newPassword !== confirmPassword) { toast.error('Passwörter stimmen nicht überein'); return; }
    if (newPassword.length < 6) { toast.error('Neues Passwort muss mindestens 6 Zeichen lang sein'); return; }

    setSavingPw(true);
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ oldPassword, newPassword }),
      });
      const data = await res.json();
      if (res.ok) {
        toast.success('Passwort geändert');
        setOldPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        toast.error(data?.error ?? 'Fehler');
      }
    } catch { toast.error('Fehler'); }
    finally { setSavingPw(false); }
  };

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="w-8 h-8 border-3 border-[#001957] border-t-transparent rounded-full animate-spin" /></div>;
  }

  return (
    <div>
      <h1 className="text-2xl font-bold text-[#001957] flex items-center gap-2 mb-6">
        <Settings className="w-6 h-6" /> Einstellungen
      </h1>

      <div className="space-y-6 max-w-2xl">
        {/* App Title */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] flex items-center gap-2 mb-4">
            <Type className="w-4 h-4 text-[#001957]" /> App-Titel
          </h2>
          <div className="flex gap-3">
            <input
              value={appTitle}
              onChange={(e) => setAppTitle(e.target.value)}
              className="flex-1 px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
              placeholder="App-Titel eingeben"
            />
            <button
              onClick={saveTitle}
              disabled={savingTitle}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium disabled:opacity-50"
            >
              <Save className="w-4 h-4" /> {savingTitle ? 'Speichern…' : 'Speichern'}
            </button>
          </div>
        </div>

        {/* Password */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] flex items-center gap-2 mb-4">
            <Lock className="w-4 h-4 text-[#001957]" /> Passwort ändern
          </h2>
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Aktuelles Passwort</label>
              <input
                type="password"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Neues Passwort</label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Neues Passwort bestätigen</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
              />
            </div>
            <button
              onClick={savePassword}
              disabled={savingPw}
              className="inline-flex items-center gap-2 px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium disabled:opacity-50"
            >
              <Save className="w-4 h-4" /> {savingPw ? 'Ändern…' : 'Passwort ändern'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
