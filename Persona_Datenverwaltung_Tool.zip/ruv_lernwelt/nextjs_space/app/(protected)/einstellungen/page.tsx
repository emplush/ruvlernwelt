import EinstellungenForm from './einstellungen-form';

export const dynamic = "force-dynamic";

export default function EinstellungenPage() {
  return <EinstellungenForm />;
}
