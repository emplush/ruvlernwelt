import AuthGuard from '@/components/auth-guard';
import Sidebar from '@/components/sidebar';

export default async function ProtectedLayout({ children }: { children: React.ReactNode }) {
  return (
    <AuthGuard>
      <div className="min-h-screen bg-[#F5F5F5]">
        <Sidebar />
        <main className="lg:ml-64 min-h-screen">
          <div className="p-4 sm:p-6 lg:p-8 max-w-[1400px]">
            {children}
          </div>
        </main>
      </div>
    </AuthGuard>
  );
}
