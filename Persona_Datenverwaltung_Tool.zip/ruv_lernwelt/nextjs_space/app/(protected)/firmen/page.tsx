import FirmenList from './firmen-list';

export const dynamic = "force-dynamic";

export default function FirmenPage() {
  return <FirmenList />;
}
