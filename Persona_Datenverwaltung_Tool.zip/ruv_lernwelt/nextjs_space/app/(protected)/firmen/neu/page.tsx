import FirmaForm from '@/components/firma-form';

export const dynamic = "force-dynamic";

export default function NeueFirmaPage() {
  return <FirmaForm />;
}
