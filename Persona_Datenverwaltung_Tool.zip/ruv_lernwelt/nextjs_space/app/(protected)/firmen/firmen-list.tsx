'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Plus, Building2, Trash2, Edit, Search } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

interface Firma {
  id: number;
  name: string;
  branche: string | null;
  strasse: string | null;
  plz: string | null;
  ort: string | null;
  personas: { persona: { id: number; vorname: string; name: string } }[];
}

export default function FirmenList() {
  const [firmen, setFirmen] = useState<Firma[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [search, setSearch] = useState('');

  const fetchFirmen = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      const res = await fetch(`/api/firmen?${params}`);
      const data = await res.json();
      setFirmen(Array.isArray(data) ? data : []);
    } catch {
      setFirmen([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(fetchFirmen, 250);
    return () => clearTimeout(t);
  }, [search]);

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch(`/api/firmen/${deleteId}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Firma gelöscht');
        fetchFirmen();
      } else {
        toast.error('Fehler beim Löschen');
      }
    } catch {
      toast.error('Fehler');
    } finally {
      setDeleteId(null);
    }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#001957] flex items-center gap-2">
            <Building2 className="w-6 h-6" /> Firmen
          </h1>
          <p className="text-sm text-gray-500 mt-1">{firmen?.length ?? 0} Firmen</p>
        </div>
        <Link
          href="/firmen/neu"
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg font-medium text-sm transition-colors shadow-sm"
        >
          <Plus className="w-4 h-4" /> Neue Firma
        </Link>
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          placeholder="Suche nach Name, Branche oder Ort…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
        />
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-3 border-[#001957] border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (firmen?.length ?? 0) === 0 ? (
        <div className="text-center py-20 text-gray-400">
          <Building2 className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Noch keine Firmen vorhanden</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <AnimatePresence mode="popLayout">
            {(firmen ?? []).map((f, i) => (
              <motion.div
                key={f.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ delay: Math.min(i * 0.03, 0.4) }}
                className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 hover:shadow-lg transition-shadow flex flex-col h-full"
              >
                <div className="flex items-start justify-between gap-2">
                  <Link href={`/firmen/${f.id}`} className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-[#001957]"><Building2 className="w-4 h-4" /></span>
                      <h3 className="font-semibold text-[#001957] truncate">{f.name}</h3>
                    </div>
                  </Link>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <Link
                      href={`/firmen/${f.id}/bearbeiten`}
                      className="p-1.5 text-gray-400 hover:text-[#001957] transition-colors"
                    >
                      <Edit className="w-4 h-4" />
                    </Link>
                    <button
                      onClick={() => setDeleteId(f.id)}
                      className="p-1.5 text-gray-400 hover:text-[#001957] transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <Link href={`/firmen/${f.id}`} className="block space-y-1.5 mt-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-gray-400 uppercase tracking-wide">Branche</span>
                    <span className="font-medium text-[#001957] truncate">{f.branche || '–'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-gray-400 uppercase tracking-wide">Personas</span>
                    <span className="font-medium text-[#001957]">{f.personas?.length ?? 0} zugeordnet</span>
                  </div>
                </Link>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {deleteId && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <h3 className="text-lg font-bold text-[#001957] mb-2">Firma löschen?</h3>
            <p className="text-sm text-gray-500 mb-6">Diese Aktion kann nicht rückgängig gemacht werden. Die Zuordnungen zu Personas werden entfernt.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setDeleteId(null)} className="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium text-[#001957] hover:bg-gray-50">Abbrechen</button>
              <button onClick={handleDelete} className="px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium">Löschen</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
