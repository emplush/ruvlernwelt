'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Edit, Trash2, Building2, User, MapPin } from 'lucide-react';
import { toast } from 'sonner';

interface FirmaData {
  id: number;
  name: string;
  funktion: string | null;
  branche: string | null;
  strasse: string | null;
  plz: string | null;
  ort: string | null;
  sonstiges: string | null;
  personas: {
    funktionInFirma: string | null;
    persona: { id: number; vorname: string; name: string; funktion: string | null };
  }[];
}

export default function FirmaDetail({ id }: { id: string }) {
  const [firma, setFirma] = useState<FirmaData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showDelete, setShowDelete] = useState(false);
  const router = useRouter();

  useEffect(() => {
    fetch(`/api/firmen/${id}`)
      .then((r) => r.json())
      .then((d) => setFirma(d))
      .catch(() => toast.error('Fehler beim Laden'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleDelete = async () => {
    try {
      const res = await fetch(`/api/firmen/${id}`, { method: 'DELETE' });
      if (res.ok) { toast.success('Firma gelöscht'); router.push('/firmen'); }
      else toast.error('Fehler');
    } catch { toast.error('Fehler'); }
  };

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="w-8 h-8 border-3 border-[#001957] border-t-transparent rounded-full animate-spin" /></div>;
  }
  if (!firma) {
    return <div className="text-center py-20 text-gray-400"><p>Firma nicht gefunden</p></div>;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <Link href="/firmen" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-[#001957]">
          <ArrowLeft className="w-4 h-4" /> Zurück
        </Link>
        <div className="flex items-center gap-2">
          <Link href={`/firmen/${id}/bearbeiten`} className="inline-flex items-center gap-2 px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium">
            <Edit className="w-4 h-4" /> Bearbeiten
          </Link>
          <button onClick={() => setShowDelete(true)} className="inline-flex items-center gap-2 px-4 py-2 border border-red-200 text-[#001957] hover:bg-red-50 rounded-lg text-sm font-medium">
            <Trash2 className="w-4 h-4" /> Löschen
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-[#001957]"><Building2 className="w-6 h-6" /></span>
          <h1 className="text-2xl font-bold text-[#001957]">{firma.name}</h1>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div><dt className="text-xs font-medium text-gray-500 uppercase">Funktion</dt><dd className="text-sm text-[#001957] mt-0.5">{firma.funktion || '–'}</dd></div>
          <div><dt className="text-xs font-medium text-gray-500 uppercase">Branche</dt><dd className="text-sm text-[#001957] mt-0.5">{firma.branche || '–'}</dd></div>
          <div>
            <dt className="text-xs font-medium text-gray-500 uppercase">Adresse</dt>
            <dd className="text-sm text-[#001957] mt-0.5 flex items-start gap-1">
              {(firma.strasse || firma.plz || firma.ort) ? (
                <>
                  <MapPin className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                  <span>{[firma.strasse, [firma.plz, firma.ort].filter(Boolean).join(' ')].filter(Boolean).join(', ')}</span>
                </>
              ) : '–'}
            </dd>
          </div>
          {firma.sonstiges && (
            <div className="sm:col-span-2">
              <dt className="text-xs font-medium text-gray-500 uppercase">Sonstiges</dt>
              <dd className="text-sm text-[#001957] mt-0.5 whitespace-pre-wrap">{firma.sonstiges}</dd>
            </div>
          )}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
        <h2 className="text-lg font-bold text-[#001957] mb-4">Zugeordnete Personas ({firma.personas?.length ?? 0})</h2>
        {(firma.personas?.length ?? 0) === 0 ? (
          <p className="text-sm text-gray-400">Keine Personas zugeordnet</p>
        ) : (
          <div className="space-y-2">
            {(firma.personas ?? []).map((fp) => (
              <Link
                key={fp.persona.id}
                href={`/personas/${fp.persona.id}`}
                className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <User className="w-4 h-4 text-gray-400" />
                <div className="min-w-0">
                  <p className="font-medium text-sm text-[#001957]">{fp.persona.vorname} {fp.persona.name}</p>
                  <p className="text-xs text-gray-500">
                    {fp.funktionInFirma ? fp.funktionInFirma : (fp.persona.funktion || 'Keine Funktion angegeben')}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      {showDelete && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <h3 className="text-lg font-bold text-[#001957] mb-2">Firma löschen?</h3>
            <p className="text-sm text-gray-500 mb-6">Diese Aktion kann nicht rückgängig gemacht werden.</p>
            <div className="flex gap-3 justify-end">
              <button onClick={() => setShowDelete(false)} className="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium text-[#001957] hover:bg-gray-50">Abbrechen</button>
              <button onClick={handleDelete} className="px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium">Löschen</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
