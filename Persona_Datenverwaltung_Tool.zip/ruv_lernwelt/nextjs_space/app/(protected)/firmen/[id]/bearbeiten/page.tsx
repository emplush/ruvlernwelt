import FirmaForm from '@/components/firma-form';

export const dynamic = "force-dynamic";

export default async function BearbeitenFirmaPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <FirmaForm firmaId={id} />;
}
