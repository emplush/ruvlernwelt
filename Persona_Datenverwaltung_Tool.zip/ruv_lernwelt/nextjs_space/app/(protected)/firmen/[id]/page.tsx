import FirmaDetail from './firma-detail';

export const dynamic = "force-dynamic";

export default async function FirmaPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <FirmaDetail id={id} />;
}
