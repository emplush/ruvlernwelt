import PersonaForm from '@/components/persona-form';

export const dynamic = "force-dynamic";

export default function NeuePage() {
  return <PersonaForm />;
}
