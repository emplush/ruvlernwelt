import PersonasList from './personas-list';

export const dynamic = "force-dynamic";

export default function PersonasPage() {
  return <PersonasList />;
}
