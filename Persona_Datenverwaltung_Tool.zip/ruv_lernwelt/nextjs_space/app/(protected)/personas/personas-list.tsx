'use client';

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Search, Plus, User, Filter, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Persona {
  id: number;
  name: string;
  vorname: string;
  funktion: string | null;
  gruppe: string | null;
  profilBildPath: string | null;
  profilBildPublic: boolean;
}

const KUNDENPROFILE = ['keine Angabe', 'Weltoffene', 'Traditionelle', 'Lebensentdecker', 'Karriereeltern', 'Familienmenschen', 'Durchstarter', 'Besonnene', 'Aktive'];

export default function PersonasList() {
  const [personas, setPersonas] = useState<Persona[]>([]);
  const [gruppen, setGruppen] = useState<string[]>([]);
  const [search, setSearch] = useState('');
  const [gruppeFilter, setGruppeFilter] = useState('');
  const [kundenprofilFilter, setKundenprofilFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [showFilter, setShowFilter] = useState(false);
  const [showKpFilter, setShowKpFilter] = useState(false);

  const fetchPersonas = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (gruppeFilter) params.set('gruppe', gruppeFilter);
      if (kundenprofilFilter) params.set('kundenprofil', kundenprofilFilter);
      const res = await fetch(`/api/personas?${params}`);
      const data = await res.json();
      setPersonas(Array.isArray(data) ? data : []);
    } catch {
      setPersonas([]);
    } finally {
      setLoading(false);
    }
  }, [search, gruppeFilter, kundenprofilFilter]);

  useEffect(() => {
    fetchPersonas();
  }, [fetchPersonas]);

  useEffect(() => {
    fetch('/api/personas/gruppen')
      .then((r) => r.json())
      .then((d) => setGruppen(Array.isArray(d) ? d : []))
      .catch(() => {});
  }, []);

  const getImageUrl = (p: Persona) => {
    if (!p.profilBildPath) return null;
    if (p.profilBildPublic && p.profilBildPath.startsWith('http')) return p.profilBildPath;
    return `/api/image/${p.id}`;
  };

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-[#001957]">Personas</h1>
          <p className="text-sm text-gray-500 mt-1">
            {personas?.length ?? 0} Personas in der Datenbank
          </p>
        </div>
        <Link
          href="/personas/neu"
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg font-medium text-sm transition-colors shadow-sm"
        >
          <Plus className="w-4 h-4" />
          Neue Persona
        </Link>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Persona suchen (Name, Funktion, Ort…)"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30 focus:border-[#001957]"
          />
        </div>
        <div className="relative">
          <button
            onClick={() => setShowFilter(!showFilter)}
            className={`inline-flex items-center gap-2 px-4 py-2.5 border rounded-lg text-sm font-medium transition-colors ${
              gruppeFilter
                ? 'bg-[#001957] text-white border-[#001957]'
                : 'bg-white text-[#001957] border-gray-200 hover:bg-gray-50'
            }`}
          >
            <Filter className="w-4 h-4" />
            {gruppeFilter || 'Gruppe'}
            {gruppeFilter && (
              <X
                className="w-3 h-3 ml-1"
                onClick={(e) => {
                  e.stopPropagation();
                  setGruppeFilter('');
                }}
              />
            )}
          </button>
          {showFilter && (
            <div className="absolute right-0 mt-1 w-56 bg-white border border-gray-200 rounded-lg shadow-lg z-20 py-1 max-h-72 overflow-y-auto">
              <button
                onClick={() => { setGruppeFilter(''); setShowFilter(false); }}
                className="w-full text-left px-4 py-2 text-sm text-gray-500 hover:bg-gray-50"
              >
                Alle Gruppen
              </button>
              {gruppen.map((g) => (
                <button
                  key={g}
                  onClick={() => { setGruppeFilter(g); setShowFilter(false); }}
                  className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 ${
                    gruppeFilter === g ? 'text-[#001957] font-medium' : 'text-[#001957]'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="relative">
          <button
            onClick={() => setShowKpFilter(!showKpFilter)}
            className={`inline-flex items-center gap-2 px-4 py-2.5 border rounded-lg text-sm font-medium transition-colors ${
              kundenprofilFilter
                ? 'bg-[#001957] text-white border-[#001957]'
                : 'bg-white text-[#001957] border-gray-200 hover:bg-gray-50'
            }`}
          >
            <Filter className="w-4 h-4" />
            {kundenprofilFilter || 'Kundenprofil'}
            {kundenprofilFilter && (
              <X
                className="w-3 h-3 ml-1"
                onClick={(e) => { e.stopPropagation(); setKundenprofilFilter(''); }}
              />
            )}
          </button>
          {showKpFilter && (
            <div className="absolute right-0 mt-1 w-56 bg-white border border-gray-200 rounded-lg shadow-lg z-20 py-1 max-h-72 overflow-y-auto">
              <button
                onClick={() => { setKundenprofilFilter(''); setShowKpFilter(false); }}
                className="w-full text-left px-4 py-2 text-sm text-gray-500 hover:bg-gray-50"
              >
                Alle Kundenprofile
              </button>
              {KUNDENPROFILE.map((k) => (
                <button
                  key={k}
                  onClick={() => { setKundenprofilFilter(k); setShowKpFilter(false); }}
                  className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 ${
                    kundenprofilFilter === k ? 'text-[#001957] font-medium' : 'text-[#001957]'
                  }`}
                >
                  {k}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* List */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-8 h-8 border-3 border-[#001957] border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (personas?.length ?? 0) === 0 ? (
        <div className="text-center py-20 text-gray-400">
          <User className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Keine Personas gefunden</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          <AnimatePresence mode="popLayout">
            {(personas ?? []).map((p, i) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ delay: Math.min(i * 0.02, 0.5) }}
              >
                <Link
                  href={`/personas/${p.id}`}
                  className="flex flex-col items-center text-center p-4 bg-white rounded-xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100 group h-full"
                >
                  <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0 overflow-hidden mb-3">
                    {p.profilBildPath ? (
                      <div className="relative w-20 h-20">
                        <Image
                          src={getImageUrl(p) ?? ''}
                          alt={`${p.vorname} ${p.name}`}
                          fill
                          className="object-cover rounded-full"
                          onError={(e: any) => { e.currentTarget.style.display = 'none'; }}
                        />
                      </div>
                    ) : (
                      <User className="w-8 h-8 text-gray-400" />
                    )}
                  </div>
                  <p className="font-semibold text-[#001957] text-sm leading-tight mb-1">
                    {p.vorname} {p.name}
                  </p>
                  <p className="text-xs text-gray-500 leading-tight mb-1 line-clamp-2">
                    {p.funktion ?? '–'}
                  </p>
                  {p.gruppe && (
                    <span className="inline-block mt-auto px-2 py-0.5 bg-[#001957]/8 text-[#001957] text-[10px] font-medium rounded-full">
                      {p.gruppe}
                    </span>
                  )}
                </Link>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
