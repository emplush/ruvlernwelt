import PersonaDetail from './persona-detail';

export const dynamic = "force-dynamic";

export default async function PersonaPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <PersonaDetail id={id} />;
}
