import PersonaForm from '@/components/persona-form';

export const dynamic = "force-dynamic";

export default async function BearbeitenPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <PersonaForm personaId={id} />;
}
