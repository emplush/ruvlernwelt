'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import {
  ArrowLeft, Edit, Trash2, User, MapPin, Briefcase, Heart, Brain, Mic, ExternalLink, BookOpen, Users, Building2, Plus, X, FolderOpen, Copy
} from 'lucide-react';
import { toast } from 'sonner';

function toExplorerUrl(raw: string): string {
  const p = (raw ?? '').trim();
  if (!p) return p;
  if (/^(file:|https?:)/i.test(p)) return p;
  // UNC-Pfad \\\\server\\share\\ordner
  if (p.startsWith('\\\\')) {
    return 'file://' + p.slice(2).replace(/\\/g, '/');
  }
  // Laufwerkspfad C:\\ordner
  if (/^[a-zA-Z]:[\\/]/.test(p)) {
    return 'file:///' + p.replace(/\\/g, '/');
  }
  return p;
}

interface FormatPersona {
  format: { id: number; name: string; formatTyp: string; medienentwickler: string };
}

interface FirmaMembership {
  firmaId: number;
  funktionInFirma: string | null;
  firma: { id: number; name: string; branche: string | null; ort: string | null };
}

interface Relation {
  id: number;
  verhaeltnis: string | null;
  relatedPersona?: { id: number; vorname: string; name: string };
  persona?: { id: number; vorname: string; name: string };
}

interface PersonaData {
  id: number;
  personaId: number | null;
  name: string;
  vorname: string;
  gruppe: string | null;
  funktion: string | null;
  kundenprofil: string | null;
  cJourney: string | null;
  geschlecht: string | null;
  herkunft: string | null;
  geburtstag: string | null;
  alter: number | null;
  strasse: string | null;
  plz: string | null;
  ort: string | null;
  stadtteil: string | null;
  beruf: string | null;
  familienstand: string | null;
  wohnart: string | null;
  verwandt: string | null;
  lebenslauf: string | null;
  aktivitaeten: string | null;
  charakter: string | null;
  sonstiges: string | null;
  wocStimme: string | null;
  didAvatar: string | null;
  bilderLink: string | null;
  profilBildPath: string | null;
  profilBildPublic: boolean;
  formats: FormatPersona[];
  firmen: FirmaMembership[];
  relationsFrom: Relation[];
  relationsTo: Relation[];
}

interface PersonaOption { id: number; vorname: string; name: string; }

function Section({ title, icon, children, action }: { title: string; icon: React.ReactNode; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          {icon}
          <h2 className="text-lg font-bold text-[#001957]">{title}</h2>
        </div>
        {action}
      </div>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string | number | null | undefined }) {
  if (!value && value !== 0) return null;
  const displayValue = String(value);
  const isMultiline = displayValue.includes('\n') || displayValue.includes('\r');
  return (
    <div>
      <dt className="text-xs font-medium text-gray-500 uppercase tracking-wide">{label}</dt>
      {isMultiline ? (
        <dd className="text-sm text-[#001957] mt-0.5 whitespace-pre-line">{displayValue}</dd>
      ) : (
        <dd className="text-sm text-[#001957] mt-0.5">{displayValue}</dd>
      )}
    </div>
  );
}

export default function PersonaDetail({ id }: { id: string }) {
  const [persona, setPersona] = useState<PersonaData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showDelete, setShowDelete] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [allPersonas, setAllPersonas] = useState<PersonaOption[]>([]);
  const [showAddRelation, setShowAddRelation] = useState(false);
  const [relPersonaId, setRelPersonaId] = useState('');
  const [relVerhaeltnis, setRelVerhaeltnis] = useState('');
  const [savingRel, setSavingRel] = useState(false);
  const router = useRouter();

  const loadPersona = useCallback(() => {
    return fetch(`/api/personas/${id}`)
      .then((r) => r.json())
      .then((d) => {
        setPersona(d);
        if (d?.profilBildPath) {
          fetch(`/api/image/${d.id}`)
            .then((r) => r.json())
            .then((img) => setImageUrl(img?.url ?? null))
            .catch(() => {});
        }
      })
      .catch(() => toast.error('Fehler beim Laden'));
  }, [id]);

  useEffect(() => {
    loadPersona().finally(() => setLoading(false));
    fetch('/api/personas')
      .then((r) => r.json())
      .then((d) => setAllPersonas(Array.isArray(d) ? d.map((p: any) => ({ id: p.id, vorname: p.vorname, name: p.name })) : []))
      .catch(() => {});
  }, [loadPersona]);

  const handleDelete = async () => {
    try {
      const res = await fetch(`/api/personas/${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Persona gelöscht');
        router.push('/personas');
      } else {
        toast.error('Fehler beim Löschen');
      }
    } catch {
      toast.error('Fehler beim Löschen');
    }
  };

  const handleAddRelation = async () => {
    if (!relPersonaId) { toast.error('Bitte eine Persona wählen'); return; }
    setSavingRel(true);
    try {
      const res = await fetch(`/api/personas/${id}/relations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ relatedPersonaId: Number(relPersonaId), verhaeltnis: relVerhaeltnis || null }),
      });
      if (res.ok) {
        toast.success('Familienbeziehung hinzugefügt');
        setRelPersonaId(''); setRelVerhaeltnis(''); setShowAddRelation(false);
        await loadPersona();
      } else {
        const err = await res.json().catch(() => ({}));
        toast.error(err?.error ?? 'Fehler');
      }
    } catch {
      toast.error('Fehler beim Speichern');
    } finally {
      setSavingRel(false);
    }
  };

  const handleDeleteRelation = async (relationId: number) => {
    try {
      const res = await fetch(`/api/personas/${id}/relations?relationId=${relationId}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('Beziehung entfernt');
        await loadPersona();
      } else {
        toast.error('Fehler beim Entfernen');
      }
    } catch {
      toast.error('Fehler');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-3 border-[#001957] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!persona) {
    return (
      <div className="text-center py-20 text-gray-400">
        <p>Persona nicht gefunden</p>
        <Link href="/personas" className="text-[#001957] hover:underline mt-2 inline-block">Zurück zur Liste</Link>
      </div>
    );
  }

  // Combine incoming and outgoing relations into one list
  const relations = [
    ...(persona.relationsFrom ?? []).map((r) => ({ id: r.id, verhaeltnis: r.verhaeltnis, other: r.relatedPersona })),
    ...(persona.relationsTo ?? []).map((r) => ({ id: r.id, verhaeltnis: r.verhaeltnis, other: r.persona })),
  ].filter((r) => r.other);

  return (
    <div>
      {/* Top bar */}
      <div className="flex items-center justify-between mb-6">
        <Link
          href="/personas"
          className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-[#001957] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Zurück
        </Link>
        <div className="flex items-center gap-2">
          <Link
            href={`/personas/${id}/bearbeiten`}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium transition-colors"
          >
            <Edit className="w-4 h-4" /> Bearbeiten
          </Link>
          <button
            onClick={() => setShowDelete(true)}
            className="inline-flex items-center gap-2 px-4 py-2 border border-red-200 text-[#001957] hover:bg-red-50 rounded-lg text-sm font-medium transition-colors"
          >
            <Trash2 className="w-4 h-4" /> Löschen
          </button>
        </div>
      </div>

      {/* Profile header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 mb-6">
        <div className="flex flex-col sm:flex-row items-start gap-6">
          <div className="w-28 h-28 rounded-xl bg-gray-100 flex items-center justify-center overflow-hidden flex-shrink-0">
            {imageUrl ? (
              <div className="relative w-28 h-28">
                <Image
                  src={imageUrl}
                  alt={`${persona.vorname} ${persona.name}`}
                  fill
                  className="object-cover rounded-xl"
                  onError={(e: any) => { e.currentTarget.style.display = 'none'; }}
                />
              </div>
            ) : (
              <User className="w-12 h-12 text-gray-300" />
            )}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-[#001957]">
              {persona.vorname} {persona.name}
            </h1>
            <p className="text-gray-500 mt-1">{persona.funktion ?? '–'}</p>
            {persona.gruppe && (
              <span className="inline-block mt-2 px-3 py-1 bg-[#001957]/10 text-[#001957] text-xs font-medium rounded-full">
                {persona.gruppe}
              </span>
            )}
            {persona.personaId && (
              <span className="inline-block mt-2 ml-2 px-3 py-1 bg-gray-100 text-gray-500 text-xs rounded-full">
                ID: {persona.personaId}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Section title="Persönliche Daten" icon={<User className="w-5 h-5 text-[#001957]" />}>
          <Field label="Vorname" value={persona.vorname} />
          <Field label="Name" value={persona.name} />
          <Field label="Geschlecht" value={persona.geschlecht} />
          <Field label="Geburtstag" value={persona.geburtstag} />
          <Field label="Alter" value={persona.alter} />
          <Field label="Herkunft" value={persona.herkunft} />
        </Section>

        <Section title="Kontakt & Wohnen" icon={<MapPin className="w-5 h-5 text-[#001957]" />}>
          <Field label="Straße" value={persona.strasse} />
          <Field label="PLZ" value={persona.plz} />
          <Field label="Ort" value={persona.ort} />
          <Field label="Stadtteil" value={persona.stadtteil} />
          <Field label="Wohnart" value={persona.wohnart} />
        </Section>

        <Section title="Beruf & Rolle" icon={<Briefcase className="w-5 h-5 text-[#001957]" />}>
          <Field label="Funktion in der Lernwelt" value={persona.funktion} />
          <Field label="Gruppe" value={persona.gruppe} />
          <Field label="Beruf" value={persona.beruf} />
          <Field label="Kundenprofil" value={persona.kundenprofil} />
          <Field label="Customer Journey" value={persona.cJourney} />
        </Section>

        <Section title="Biografie" icon={<Heart className="w-5 h-5 text-[#001957]" />}>
          <Field label="Familienstand" value={persona.familienstand} />
          <Field label="Weitere Familienangaben" value={persona.verwandt} />
          <Field label="Lebenslauf" value={persona.lebenslauf} />
        </Section>

        {/* Familie – Beziehungen zu anderen Personas */}
        <Section
          title="Familie"
          icon={<Users className="w-5 h-5 text-[#001957]" />}
          action={
            <button
              onClick={() => setShowAddRelation((v) => !v)}
              className="inline-flex items-center gap-1 px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-medium text-[#001957] hover:bg-gray-50 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Beziehung
            </button>
          }
        >
          {showAddRelation && (
            <div className="bg-gray-50 rounded-lg p-4 mb-2 space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Person</label>
                <select
                  value={relPersonaId}
                  onChange={(e) => setRelPersonaId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
                >
                  <option value="">– Persona wählen –</option>
                  {allPersonas.filter((p) => p.id !== persona.id).map((p) => (
                    <option key={p.id} value={p.id}>{p.vorname} {p.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Verwandtschaftsverhältnis</label>
                <input
                  type="text"
                  value={relVerhaeltnis}
                  onChange={(e) => setRelVerhaeltnis(e.target.value)}
                  placeholder="z. B. Ehepartner, Tochter, Bruder…"
                  className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
                />
              </div>
              <div className="flex gap-2 justify-end">
                <button
                  onClick={() => { setShowAddRelation(false); setRelPersonaId(''); setRelVerhaeltnis(''); }}
                  className="px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-medium text-[#001957] hover:bg-gray-50"
                >
                  Abbrechen
                </button>
                <button
                  onClick={handleAddRelation}
                  disabled={savingRel}
                  className="px-3 py-1.5 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-xs font-medium disabled:opacity-50"
                >
                  {savingRel ? 'Speichern…' : 'Hinzufügen'}
                </button>
              </div>
            </div>
          )}
          {relations.length === 0 ? (
            <p className="text-sm text-gray-400">Keine Familienbeziehungen erfasst.</p>
          ) : (
            <div className="space-y-2">
              {relations.map((r) => (
                <div key={r.id} className="flex items-center justify-between gap-3 p-3 bg-gray-50 rounded-lg">
                  <Link href={`/personas/${r.other!.id}`} className="flex items-center gap-3 min-w-0">
                    <Users className="w-4 h-4 text-gray-400 flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="font-medium text-sm text-[#001957] truncate">{r.other!.vorname} {r.other!.name}</p>
                      {r.verhaeltnis && <p className="text-xs text-gray-500">{r.verhaeltnis}</p>}
                    </div>
                  </Link>
                  <button
                    onClick={() => handleDeleteRelation(r.id)}
                    className="p-1.5 text-gray-400 hover:text-[#FF4C4C] transition-colors flex-shrink-0"
                    aria-label="Beziehung entfernen"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </Section>

        <Section title="Persönlichkeit" icon={<Brain className="w-5 h-5 text-[#001957]" />}>
          <Field label="Charakter" value={persona.charakter} />
          <Field label="Aktivitäten" value={persona.aktivitaeten} />
          <Field label="Sonstiges" value={persona.sonstiges} />
        </Section>

        {(persona.firmen?.length ?? 0) > 0 && (
          <Section title="Firmenzugehörigkeit" icon={<Building2 className="w-5 h-5 text-[#001957]" />}>
            <div className="space-y-2">
              {(persona.firmen ?? []).map((fm) => (
                <Link
                  key={fm.firmaId}
                  href={`/firmen/${fm.firma.id}`}
                  className="block p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <p className="font-medium text-sm text-[#001957]">{fm.firma.name}</p>
                  <p className="text-xs text-gray-500">
                    {fm.funktionInFirma ? fm.funktionInFirma : 'Funktion nicht angegeben'}
                    {fm.firma.branche ? ` · ${fm.firma.branche}` : ''}
                  </p>
                </Link>
              ))}
            </div>
          </Section>
        )}

        <Section title="Voiceover & Avatar" icon={<Mic className="w-5 h-5 text-[#001957]" />}>
          <Field label="WoC-Stimme" value={persona.wocStimme} />
          <Field label="DID-Avatar" value={persona.didAvatar} />
        </Section>

        {persona.bilderLink && (
          <Section title="Links & Medien" icon={<FolderOpen className="w-5 h-5 text-[#001957]" />}>
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-3">
                <a
                  href={toExplorerUrl(persona.bilderLink)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm font-medium text-[#001957] hover:underline"
                >
                  <FolderOpen className="w-4 h-4" />
                  Ordner im Explorer öffnen
                </a>
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(persona.bilderLink ?? '')
                      .then(() => toast.success('Pfad kopiert'))
                      .catch(() => toast.error('Kopieren nicht möglich'));
                  }}
                  className="inline-flex items-center gap-2 text-sm text-[#109DA8] hover:text-[#001957] hover:underline"
                >
                  <Copy className="w-4 h-4" />
                  Pfad kopieren
                </button>
              </div>
              <p className="text-xs text-gray-500 break-all">{persona.bilderLink}</p>
              <p className="text-xs text-gray-400">
                Hinweis: Aus Sicherheitsgründen können Browser lokale Ordner nicht immer direkt öffnen. Falls sich der Explorer nicht öffnet, kopieren Sie den Pfad und fügen ihn in die Adresszeile des Windows-Explorers ein.
              </p>
            </div>
          </Section>
        )}

        {(persona.formats?.length ?? 0) > 0 && (
          <Section title="Zugewiesene E-Learning-Formate" icon={<BookOpen className="w-5 h-5 text-[#001957]" />}>
            <div className="space-y-2">
              {(persona.formats ?? []).map((fp: FormatPersona) => (
                <Link
                  key={fp.format.id}
                  href={`/formate/${fp.format.id}`}
                  className="block p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <p className="font-medium text-sm text-[#001957]">{fp.format.name}</p>
                  <p className="text-xs text-gray-500">{fp.format.formatTyp} · {fp.format.medienentwickler}</p>
                </Link>
              ))}
            </div>
          </Section>
        )}
      </div>

      {/* Delete Dialog */}
      {showDelete && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-sm w-full p-6">
            <h3 className="text-lg font-bold text-[#001957] mb-2">Persona löschen?</h3>
            <p className="text-sm text-gray-500 mb-6">
              Möchten Sie <strong>{persona.vorname} {persona.name}</strong> wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.
            </p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setShowDelete(false)}
                className="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium text-[#001957] hover:bg-gray-50 transition-colors"
              >
                Abbrechen
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium transition-colors"
              >
                Löschen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
