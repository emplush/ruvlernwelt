export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuth } from "@/lib/auth";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  const format = await prisma.format.findUnique({
    where: { id: parseInt(id) },
    include: { personas: { include: { persona: true } } },
  });
  if (!format) return NextResponse.json({ error: "Nicht gefunden" }, { status: 404 });
  return NextResponse.json(format);
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  try {
    const { name, formatTyp, medienentwickler, formatId: formatIdNum, link, httpLink, personaIds } = await req.json();
    const formatId = parseInt(id);

    // Delete existing persona associations
    await prisma.formatPersona.deleteMany({ where: { formatId } });

    const format = await prisma.format.update({
      where: { id: formatId },
      data: {
        name,
        formatTyp,
        medienentwickler,
        formatId: formatIdNum != null && formatIdNum !== "" ? parseInt(String(formatIdNum)) : null,
        link: link || null,
        httpLink: httpLink || null,
        personas: personaIds?.length
          ? { create: personaIds.map((pid: number) => ({ personaId: pid })) }
          : undefined,
      },
      include: { personas: { include: { persona: true } } },
    });
    return NextResponse.json(format);
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  try {
    await prisma.format.delete({ where: { id: parseInt(id) } });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}
