export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuth } from "@/lib/auth";

export async function GET() {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const formate = await prisma.format.findMany({
    orderBy: { name: "asc" },
    include: { personas: { include: { persona: true } } },
  });
  return NextResponse.json(formate);
}

export async function POST(req: NextRequest) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  try {
    const { name, formatTyp, medienentwickler, formatId, link, httpLink, personaIds } = await req.json();
    const format = await prisma.format.create({
      data: {
        name,
        formatTyp,
        medienentwickler,
        formatId: formatId != null && formatId !== "" ? parseInt(String(formatId)) : null,
        link: link || null,
        httpLink: httpLink || null,
        personas: personaIds?.length
          ? { create: personaIds.map((pid: number) => ({ personaId: pid })) }
          : undefined,
      },
      include: { personas: { include: { persona: true } } },
    });
    return NextResponse.json(format, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}
