export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuth } from "@/lib/auth";
import { getFileUrl } from "@/lib/s3";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  const persona = await prisma.persona.findUnique({ where: { id: parseInt(id) } });
  if (!persona?.profilBildPath) {
    return NextResponse.json({ url: null });
  }

  try {
    const url = await getFileUrl(persona.profilBildPath, 'image/jpeg', persona.profilBildPublic);
    return NextResponse.json({ url });
  } catch {
    return NextResponse.json({ url: null });
  }
}
