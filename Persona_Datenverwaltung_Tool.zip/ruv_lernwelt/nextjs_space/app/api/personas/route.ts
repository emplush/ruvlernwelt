export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuth } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search") ?? "";
  const gruppe = searchParams.get("gruppe") ?? "";
  const kundenprofil = searchParams.get("kundenprofil") ?? "";

  const where: any = {};
  if (gruppe) {
    where.gruppe = gruppe;
  }
  if (kundenprofil) {
    where.kundenprofil = kundenprofil;
  }
  if (search) {
    where.OR = [
      { name: { contains: search, mode: "insensitive" } },
      { vorname: { contains: search, mode: "insensitive" } },
      { funktion: { contains: search, mode: "insensitive" } },
      { beruf: { contains: search, mode: "insensitive" } },
      { ort: { contains: search, mode: "insensitive" } },
      { gruppe: { contains: search, mode: "insensitive" } },
    ];
  }

  const personas = await prisma.persona.findMany({
    where,
    orderBy: [{ name: "asc" }, { vorname: "asc" }],
    include: { formats: { include: { format: true } } },
  });

  return NextResponse.json(personas);
}

export async function POST(req: NextRequest) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  try {
    const body = await req.json();
    const { firmenAssignments, relationAssignments, ...personaData } = body ?? {};
    const persona = await prisma.persona.create({
      data: {
        ...personaData,
        firmen: Array.isArray(firmenAssignments) && firmenAssignments.length
          ? { create: firmenAssignments.map((a: any) => ({ firmaId: a.firmaId, funktionInFirma: a.funktionInFirma || null })) }
          : undefined,
        relationsFrom: Array.isArray(relationAssignments) && relationAssignments.length
          ? { create: relationAssignments
              .filter((a: any) => a.relatedPersonaId)
              .map((a: any) => ({ relatedPersonaId: Number(a.relatedPersonaId), verhaeltnis: a.verhaeltnis || null })) }
          : undefined,
      },
    });
    return NextResponse.json(persona, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}
