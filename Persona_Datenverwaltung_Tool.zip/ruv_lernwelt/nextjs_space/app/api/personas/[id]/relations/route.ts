export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuth } from "@/lib/auth";

// Create a family relation from this persona to another persona
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  try {
    const personaId = parseInt(id);
    const { relatedPersonaId, verhaeltnis } = await req.json();
    const relId = parseInt(String(relatedPersonaId));
    if (!relId || relId === personaId) {
      return NextResponse.json({ error: "Ungültige Persona-Auswahl" }, { status: 400 });
    }
    const existing = await prisma.personaRelation.findFirst({
      where: {
        OR: [
          { personaId, relatedPersonaId: relId },
          { personaId: relId, relatedPersonaId: personaId },
        ],
      },
    });
    if (existing) {
      return NextResponse.json({ error: "Diese Beziehung besteht bereits" }, { status: 409 });
    }
    const relation = await prisma.personaRelation.create({
      data: { personaId, relatedPersonaId: relId, verhaeltnis: verhaeltnis || null },
      include: { relatedPersona: true },
    });
    return NextResponse.json(relation, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}

// Delete a family relation by relationId
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  await params;
  try {
    const { searchParams } = new URL(req.url);
    const relationId = parseInt(searchParams.get("relationId") ?? "");
    if (!relationId) return NextResponse.json({ error: "relationId fehlt" }, { status: 400 });
    await prisma.personaRelation.delete({ where: { id: relationId } });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}
