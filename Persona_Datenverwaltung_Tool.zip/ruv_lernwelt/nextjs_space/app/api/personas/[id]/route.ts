export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuth } from "@/lib/auth";
import { deleteFile } from "@/lib/s3";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  const persona = await prisma.persona.findUnique({
    where: { id: parseInt(id) },
    include: {
      formats: { include: { format: true } },
      firmen: { include: { firma: true } },
      relationsFrom: { include: { relatedPersona: true } },
      relationsTo: { include: { persona: true } },
    },
  });
  if (!persona) return NextResponse.json({ error: "Nicht gefunden" }, { status: 404 });
  return NextResponse.json(persona);
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  try {
    const body = await req.json();
    const { firmenAssignments, relationAssignments, ...personaData } = body ?? {};
    const personaId = parseInt(id);

    // Profilbild-Löschung: altes Bild aus dem Speicher entfernen
    if (Object.prototype.hasOwnProperty.call(personaData, "profilBildPath") && !personaData.profilBildPath) {
      const existing = await prisma.persona.findUnique({ where: { id: personaId } });
      if (existing?.profilBildPath) {
        try { await deleteFile(existing.profilBildPath); } catch {}
      }
    }

    if (Array.isArray(firmenAssignments)) {
      await prisma.firmaPersona.deleteMany({ where: { personaId } });
    }
    if (Array.isArray(relationAssignments)) {
      await prisma.personaRelation.deleteMany({
        where: { OR: [{ personaId }, { relatedPersonaId: personaId }] },
      });
    }
    const persona = await prisma.persona.update({
      where: { id: personaId },
      data: {
        ...personaData,
        firmen: Array.isArray(firmenAssignments) && firmenAssignments.length
          ? { create: firmenAssignments.map((a: any) => ({ firmaId: a.firmaId, funktionInFirma: a.funktionInFirma || null })) }
          : undefined,
        relationsFrom: Array.isArray(relationAssignments) && relationAssignments.length
          ? { create: relationAssignments
              .filter((a: any) => a.relatedPersonaId)
              .map((a: any) => ({ relatedPersonaId: Number(a.relatedPersonaId), verhaeltnis: a.verhaeltnis || null })) }
          : undefined,
      },
    });
    return NextResponse.json(persona);
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  try {
    const persona = await prisma.persona.findUnique({ where: { id: parseInt(id) } });
    if (persona?.profilBildPath) {
      try { await deleteFile(persona.profilBildPath); } catch {}
    }
    await prisma.persona.delete({ where: { id: parseInt(id) } });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}
