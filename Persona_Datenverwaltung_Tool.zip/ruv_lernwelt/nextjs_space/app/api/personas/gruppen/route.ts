export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuth } from "@/lib/auth";

export async function GET() {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const gruppen = await prisma.persona.findMany({
    where: { gruppe: { not: null } },
    select: { gruppe: true },
    distinct: ["gruppe"],
    orderBy: { gruppe: "asc" },
  });

  return NextResponse.json(gruppen.map((g: any) => g.gruppe).filter(Boolean));
}
