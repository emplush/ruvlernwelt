export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuth } from "@/lib/auth";

export async function GET() {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const settings = await prisma.settings.findUnique({ where: { id: 1 } });
  return NextResponse.json({ appTitle: settings?.appTitle ?? "R+V Lernwelt \u2013 Persona-Datenbank" });
}

export async function PUT(req: NextRequest) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  try {
    const body = await req.json();
    const data: any = {};

    if (body.appTitle !== undefined) {
      data.appTitle = body.appTitle;
    }

    if (body.newPassword) {
      const settings = await prisma.settings.findUnique({ where: { id: 1 } });
      if (settings?.password !== body.oldPassword) {
        return NextResponse.json({ error: "Altes Passwort ist falsch" }, { status: 400 });
      }
      data.password = body.newPassword;
    }

    const updated = await prisma.settings.upsert({
      where: { id: 1 },
      update: data,
      create: { id: 1, ...data },
    });

    return NextResponse.json({ success: true, appTitle: updated.appTitle });
  } catch {
    return NextResponse.json({ error: "Serverfehler" }, { status: 500 });
  }
}
