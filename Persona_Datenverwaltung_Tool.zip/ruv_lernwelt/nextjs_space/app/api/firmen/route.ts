export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuth } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search") ?? "";

  const where: any = {};
  if (search) {
    where.OR = [
      { name: { contains: search, mode: "insensitive" } },
      { branche: { contains: search, mode: "insensitive" } },
      { ort: { contains: search, mode: "insensitive" } },
    ];
  }

  const firmen = await prisma.firma.findMany({
    where,
    orderBy: { name: "asc" },
    include: { personas: { include: { persona: true } } },
  });
  return NextResponse.json(firmen);
}

export async function POST(req: NextRequest) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  try {
    const { name, funktion, branche, strasse, plz, ort, sonstiges, personaAssignments } = await req.json();
    if (!name || !String(name).trim()) {
      return NextResponse.json({ error: "Name ist ein Pflichtfeld" }, { status: 400 });
    }
    const firma = await prisma.firma.create({
      data: {
        name,
        funktion: funktion || null,
        branche: branche || null,
        strasse: strasse || null,
        plz: plz || null,
        ort: ort || null,
        sonstiges: sonstiges || null,
        personas: Array.isArray(personaAssignments) && personaAssignments.length
          ? { create: personaAssignments.map((a: any) => ({ personaId: a.personaId, funktionInFirma: a.funktionInFirma || null })) }
          : undefined,
      },
      include: { personas: { include: { persona: true } } },
    });
    return NextResponse.json(firma, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}
