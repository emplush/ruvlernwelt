export const dynamic = "force-dynamic";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyAuth } from "@/lib/auth";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  const firma = await prisma.firma.findUnique({
    where: { id: parseInt(id) },
    include: { personas: { include: { persona: true } } },
  });
  if (!firma) return NextResponse.json({ error: "Nicht gefunden" }, { status: 404 });
  return NextResponse.json(firma);
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  try {
    const { name, funktion, branche, strasse, plz, ort, sonstiges, personaAssignments } = await req.json();
    const firmaId = parseInt(id);

    if (Array.isArray(personaAssignments)) {
      await prisma.firmaPersona.deleteMany({ where: { firmaId } });
    }

    const firma = await prisma.firma.update({
      where: { id: firmaId },
      data: {
        name,
        funktion: funktion || null,
        branche: branche || null,
        strasse: strasse || null,
        plz: plz || null,
        ort: ort || null,
        sonstiges: sonstiges || null,
        personas: Array.isArray(personaAssignments) && personaAssignments.length
          ? { create: personaAssignments.map((a: any) => ({ personaId: a.personaId, funktionInFirma: a.funktionInFirma || null })) }
          : undefined,
      },
      include: { personas: { include: { persona: true } } },
    });
    return NextResponse.json(firma);
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const isAuth = await verifyAuth();
  if (!isAuth) return NextResponse.json({ error: "Nicht autorisiert" }, { status: 401 });

  const { id } = await params;
  try {
    await prisma.firma.delete({ where: { id: parseInt(id) } });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Fehler" }, { status: 500 });
  }
}
