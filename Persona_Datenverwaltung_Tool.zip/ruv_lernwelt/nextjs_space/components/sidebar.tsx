'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import Image from 'next/image';
import { Users, BookOpen, Settings, LogOut, Menu, X, ChevronRight, Building2 } from 'lucide-react';

const navItems = [
  { href: '/personas', label: 'Personas', icon: Users },
  { href: '/firmen', label: 'Firmen', icon: Building2 },
  { href: '/formate', label: 'E-Learning-Formate', icon: BookOpen },
  { href: '/einstellungen', label: 'Einstellungen', icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [appTitle, setAppTitle] = useState('R+V Lernwelt');

  useEffect(() => {
    fetch('/api/settings')
      .then((r) => r.json())
      .then((d) => {
        if (d?.appTitle) setAppTitle(d.appTitle);
      })
      .catch(() => {});
  }, []);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
    router.refresh();
  };

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setOpen(!open)}
        className="fixed top-4 left-4 z-50 lg:hidden p-2 bg-[#001957] text-white rounded-lg shadow-md"
        aria-label="Menü"
      >
        {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {/* Overlay */}
      {open && (
        <div
          className="fixed inset-0 bg-black/40 z-30 lg:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-64 bg-[#001957] text-white z-40 flex flex-col transition-transform duration-300 ${
          open ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0`}
      >
        {/* Brand */}
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="bg-white rounded-lg px-3 py-2 flex items-center justify-center flex-shrink-0">
              <Image
                src="/ruv-logo.png"
                alt="R+V Logo"
                width={56}
                height={37}
                className="h-8 w-auto"
                priority
              />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-bold text-white truncate leading-tight">{appTitle}</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-3 space-y-1">
          {navItems.map((item) => {
            const active = pathname?.startsWith(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors border-l-4 ${
                  active
                    ? 'bg-white/15 text-white border-[#00DCDC]'
                    : 'text-white/70 hover:bg-white/10 hover:text-white border-transparent'
                }`}
              >
                <Icon className={`w-5 h-5 flex-shrink-0 ${active ? 'text-[#00DCDC]' : ''}`} />
                <span>{item.label}</span>
                {active && <ChevronRight className="w-4 h-4 ml-auto" />}
              </Link>
            );
          })}
        </nav>

        {/* Logout */}
        <div className="p-3 border-t border-white/10">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:bg-white/10 hover:text-white w-full transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Abmelden</span>
          </button>
        </div>
      </aside>
    </>
  );
}
