'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Save, Search, Plus, X } from 'lucide-react';
import { toast } from 'sonner';

interface Persona {
  id: number; vorname: string; name: string; funktion: string | null;
}

interface Assignment {
  personaId: number;
  funktionInFirma: string;
}

export default function FirmaForm({ firmaId }: { firmaId?: string }) {
  const [name, setName] = useState('');
  const [funktion, setFunktion] = useState('');
  const [branche, setBranche] = useState('');
  const [strasse, setStrasse] = useState('');
  const [plz, setPlz] = useState('');
  const [ort, setOrt] = useState('');
  const [sonstiges, setSonstiges] = useState('');
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [allPersonas, setAllPersonas] = useState<Persona[]>([]);
  const [personaSearch, setPersonaSearch] = useState('');
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const isEdit = !!firmaId;

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const pRes = await fetch('/api/personas');
        const pData = await pRes.json();
        setAllPersonas(Array.isArray(pData) ? pData : []);

        if (firmaId) {
          const fRes = await fetch(`/api/firmen/${firmaId}`);
          const fData = await fRes.json();
          setName(fData?.name ?? '');
          setFunktion(fData?.funktion ?? '');
          setBranche(fData?.branche ?? '');
          setStrasse(fData?.strasse ?? '');
          setPlz(fData?.plz ?? '');
          setOrt(fData?.ort ?? '');
          setSonstiges(fData?.sonstiges ?? '');
          setAssignments((fData?.personas ?? []).map((fp: any) => ({
            personaId: fp?.persona?.id,
            funktionInFirma: fp?.funktionInFirma ?? '',
          })).filter((a: Assignment) => a.personaId));
        }
      } catch {
        toast.error('Fehler beim Laden');
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, [firmaId]);

  const addAssignment = (pid: number) => {
    setAssignments((prev) => prev.some((a) => a.personaId === pid) ? prev : [...prev, { personaId: pid, funktionInFirma: '' }]);
    setPersonaSearch('');
  };

  const removeAssignment = (pid: number) => {
    setAssignments((prev) => prev.filter((a) => a.personaId !== pid));
  };

  const updateFunktion = (pid: number, val: string) => {
    setAssignments((prev) => prev.map((a) => a.personaId === pid ? { ...a, funktionInFirma: val } : a));
  };

  const personaById = (pid: number) => allPersonas.find((p) => p.id === pid);

  const filteredPersonas = (allPersonas ?? []).filter((p) => {
    if (assignments.some((a) => a.personaId === p.id)) return false;
    if (!personaSearch) return false;
    const q = personaSearch.toLowerCase();
    return `${p.vorname} ${p.name}`.toLowerCase().includes(q) ||
      (p.funktion ?? '').toLowerCase().includes(q);
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { toast.error('Name ist ein Pflichtfeld'); return; }

    setSaving(true);
    try {
      const body = {
        name, funktion, branche, strasse, plz, ort, sonstiges,
        personaAssignments: assignments.map((a) => ({ personaId: a.personaId, funktionInFirma: a.funktionInFirma })),
      };
      const url = isEdit ? `/api/firmen/${firmaId}` : '/api/firmen';
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (res.ok) {
        const data = await res.json();
        toast.success(isEdit ? 'Firma aktualisiert' : 'Firma erstellt');
        router.push(`/firmen/${data?.id ?? firmaId}`);
      } else {
        const err = await res.json().catch(() => ({}));
        toast.error(err?.error ?? 'Fehler');
      }
    } catch {
      toast.error('Fehler beim Speichern');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="w-8 h-8 border-3 border-[#001957] border-t-transparent rounded-full animate-spin" /></div>;
  }

  const inputCls = "w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30";

  return (
    <form onSubmit={handleSubmit}>
      <div className="flex items-center justify-between mb-6">
        <Link href={isEdit ? `/firmen/${firmaId}` : '/firmen'} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-[#001957]">
          <ArrowLeft className="w-4 h-4" /> Zurück
        </Link>
        <button type="submit" disabled={saving} className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium disabled:opacity-50">
          <Save className="w-4 h-4" /> {saving ? 'Speichern…' : 'Speichern'}
        </button>
      </div>

      <h1 className="text-2xl font-bold text-[#001957] mb-6">{isEdit ? 'Firma bearbeiten' : 'Neue Firma'}</h1>

      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] mb-4">Firmendaten</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-gray-500 mb-1">Name *</label>
              <input value={name} onChange={(e) => setName(e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Funktion</label>
              <select value={funktion} onChange={(e) => setFunktion(e.target.value)} className={inputCls}>
                <option value="">– bitte wählen –</option>
                {['keine Angabe', 'Firmenkunde', 'Gewerbekunde', 'Unternehmenskunde'].map((o) => (
                  <option key={o} value={o}>{o}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Branche</label>
              <input value={branche} onChange={(e) => setBranche(e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Straße & Hausnummer</label>
              <input value={strasse} onChange={(e) => setStrasse(e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">PLZ</label>
              <input value={plz} onChange={(e) => setPlz(e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Ort</label>
              <input value={ort} onChange={(e) => setOrt(e.target.value)} className={inputCls} />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-gray-500 mb-1">Sonstiges</label>
              <textarea value={sonstiges} onChange={(e) => setSonstiges(e.target.value)} rows={4} className={inputCls} />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] mb-4">Personas zuordnen ({assignments.length})</h2>

          {assignments.length > 0 && (
            <div className="space-y-2 mb-4">
              {assignments.map((a) => {
                const p = personaById(a.personaId);
                return (
                  <div key={a.personaId} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <div className="min-w-0 flex-shrink-0 w-40">
                      <p className="font-medium text-sm text-[#001957] truncate">{p ? `${p.vorname} ${p.name}` : `#${a.personaId}`}</p>
                    </div>
                    <input
                      value={a.funktionInFirma}
                      onChange={(e) => updateFunktion(a.personaId, e.target.value)}
                      placeholder="Funktion in der Firma…"
                      className="flex-1 px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
                    />
                    <button type="button" onClick={() => removeAssignment(a.personaId)} className="p-1.5 text-gray-400 hover:text-[#FF4C4C]">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Persona suchen und hinzufügen…"
              value={personaSearch}
              onChange={(e) => setPersonaSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
            />
            {filteredPersonas.length > 0 && (
              <div className="absolute left-0 right-0 mt-1 max-h-56 overflow-y-auto bg-white border border-gray-200 rounded-lg shadow-lg z-20">
                {filteredPersonas.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => addAssignment(p.id)}
                    className="w-full text-left flex items-center gap-2 px-3 py-2 text-sm hover:bg-gray-50 text-[#001957]"
                  >
                    <Plus className="w-3 h-3 text-gray-400" />
                    <span className="font-medium">{p.vorname} {p.name}</span>
                    {p.funktion && <span className="text-gray-400 text-xs">{p.funktion}</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </form>
  );
}
