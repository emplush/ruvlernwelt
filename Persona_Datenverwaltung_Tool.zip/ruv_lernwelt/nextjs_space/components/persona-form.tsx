'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Save, ArrowLeft, Upload, X, Plus, Building2, Users, Crop as CropIcon } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { toast } from 'sonner';
import Cropper from 'react-easy-crop';

interface PersonaFormData {
  name: string; vorname: string; gruppe: string; funktion: string;
  kundenprofil: string; cJourney: string; geschlecht: string;
  herkunft: string; geburtstag: string; alter: string;
  strasse: string; plz: string; ort: string; stadtteil: string;
  beruf: string; familienstand: string; wohnart: string;
  verwandt: string; lebenslauf: string; aktivitaeten: string;
  charakter: string; sonstiges: string; wocStimme: string;
  didAvatar: string; bilderLink: string;
}

const emptyForm: PersonaFormData = {
  name: '', vorname: '', gruppe: '', funktion: '',
  kundenprofil: '', cJourney: '', geschlecht: '',
  herkunft: '', geburtstag: '', alter: '',
  strasse: '', plz: '', ort: '', stadtteil: '',
  beruf: '', familienstand: '', wohnart: '',
  verwandt: '', lebenslauf: '', aktivitaeten: '',
  charakter: '', sonstiges: '', wocStimme: '',
  didAvatar: '', bilderLink: '',
};

const gruppeOptions = ['Privatkunde', 'Firmenkunde', 'Privat- & Firmenkunde', 'R+V Innendienst', 'R+V Außendienst', 'Bankmitarbeitende/r', 'Extern'];
const geschlechtOptions = ['männlich', 'weiblich', 'divers'];
const cJourneyOptions = ['Online', 'Offline'];
const familienstandOptions = ['ledig / Single', 'ledig / in Beziehung', 'verheiratet', 'geschieden', 'verwitwet', 'keine Angabe'];
// "keine Angabe" zuerst, restliche Einträge alphabetisch absteigend
const kundenprofilOptions = ['keine Angabe', 'Weltoffene', 'Traditionelle', 'Lebensentdecker', 'Karriereeltern', 'Familienmenschen', 'Durchstarter', 'Besonnene', 'Aktive'];
const MONTH_NAMES = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
const tagOptions = Array.from({ length: 31 }, (_, i) => String(i + 1).padStart(2, '0'));

interface Firma { id: number; name: string; }
interface FirmaAssignment { firmaId: number | ''; funktionInFirma: string; }
interface PersonaOption { id: number; vorname: string; name: string; }
interface RelationAssignment { relatedPersonaId: number | ''; verhaeltnis: string; }

function Input({ label, value, onChange, type = 'text' }: {
  label: string; value: string; onChange: (v: string) => void; type?: string;
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-500 mb-1">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30 focus:border-[#001957]"
      />
    </div>
  );
}

function SelectInput({ label, value, onChange, options }: {
  label: string; value: string; onChange: (v: string) => void; options: string[];
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-500 mb-1">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30 focus:border-[#001957]"
      >
        <option value="">– Bitte wählen –</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}

function TextArea({ label, value, onChange }: {
  label: string; value: string; onChange: (v: string) => void;
}) {
  return (
    <div>
      <label className="block text-xs font-medium text-gray-500 mb-1">{label}</label>
      <textarea
        rows={3}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30 focus:border-[#001957] resize-y"
      />
    </div>
  );
}

// Bild-Zuschnitt: liefert den gewählten Ausschnitt als JPEG-Blob
function createImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new window.Image();
    image.addEventListener('load', () => resolve(image));
    image.addEventListener('error', (e) => reject(e));
    image.src = url;
  });
}
async function getCroppedBlob(
  imageSrc: string,
  pixelCrop: { x: number; y: number; width: number; height: number }
): Promise<Blob | null> {
  const image = await createImage(imageSrc);
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  canvas.width = Math.max(1, Math.round(pixelCrop.width));
  canvas.height = Math.max(1, Math.round(pixelCrop.height));
  ctx.drawImage(
    image,
    pixelCrop.x, pixelCrop.y, pixelCrop.width, pixelCrop.height,
    0, 0, pixelCrop.width, pixelCrop.height
  );
  return new Promise((resolve) => canvas.toBlob((b) => resolve(b), 'image/jpeg', 0.9));
}

export default function PersonaForm({ personaId }: { personaId?: string }) {
  const [form, setForm] = useState<PersonaFormData>(emptyForm);
  const [gebTag, setGebTag] = useState('');
  const [gebMonat, setGebMonat] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [existingImage, setExistingImage] = useState<string | null>(null);
  const [removeImage, setRemoveImage] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(!!personaId);
  const [allFirmen, setAllFirmen] = useState<Firma[]>([]);
  const [firmaAssignments, setFirmaAssignments] = useState<FirmaAssignment[]>([]);
  const [allPersonas, setAllPersonas] = useState<PersonaOption[]>([]);
  const [relationAssignments, setRelationAssignments] = useState<RelationAssignment[]>([]);
  // Zuschnitt-Modal
  const [cropSrc, setCropSrc] = useState<string | null>(null);
  const [cropName, setCropName] = useState('bild.jpg');
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<{ x: number; y: number; width: number; height: number } | null>(null);
  const router = useRouter();

  const isEdit = !!personaId;

  useEffect(() => {
    fetch('/api/firmen')
      .then((r) => r.json())
      .then((d) => setAllFirmen(Array.isArray(d) ? d.map((f: any) => ({ id: f.id, name: f.name })) : []))
      .catch(() => {});
    fetch('/api/personas')
      .then((r) => r.json())
      .then((d) => setAllPersonas(Array.isArray(d) ? d.map((p: any) => ({ id: p.id, vorname: p.vorname, name: p.name })) : []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!personaId) return;
    fetch(`/api/personas/${personaId}`)
      .then((r) => r.json())
      .then((d: any) => {
        setForm({
          name: d?.name ?? '', vorname: d?.vorname ?? '', gruppe: d?.gruppe ?? '',
          funktion: d?.funktion ?? '', kundenprofil: d?.kundenprofil ?? '',
          cJourney: d?.cJourney ?? '', geschlecht: d?.geschlecht ?? '',
          herkunft: d?.herkunft ?? '', geburtstag: d?.geburtstag ?? '',
          alter: d?.alter != null ? String(d.alter) : '',
          strasse: d?.strasse ?? '', plz: d?.plz ?? '', ort: d?.ort ?? '',
          stadtteil: d?.stadtteil ?? '', beruf: d?.beruf ?? '',
          familienstand: d?.familienstand ?? '', wohnart: d?.wohnart ?? '',
          verwandt: d?.verwandt ?? '', lebenslauf: d?.lebenslauf ?? '',
          aktivitaeten: d?.aktivitaeten ?? '', charakter: d?.charakter ?? '',
          sonstiges: d?.sonstiges ?? '', wocStimme: d?.wocStimme ?? '',
          didAvatar: d?.didAvatar ?? '', bilderLink: d?.bilderLink ?? '',
        });
        // Geburtstag "TT. Monat" (oder Alt-Format ISO) in Tag/Monat zerlegen
        parseGeburtstag(d?.geburtstag ?? '');
        if (Array.isArray(d?.firmen)) {
          setFirmaAssignments(d.firmen.map((fp: any) => ({
            firmaId: fp.firmaId, funktionInFirma: fp.funktionInFirma ?? '',
          })));
        }
        const rels: RelationAssignment[] = [];
        if (Array.isArray(d?.relationsFrom)) {
          d.relationsFrom.forEach((r: any) => rels.push({ relatedPersonaId: r.relatedPersonaId, verhaeltnis: r.verhaeltnis ?? '' }));
        }
        if (Array.isArray(d?.relationsTo)) {
          d.relationsTo.forEach((r: any) => rels.push({ relatedPersonaId: r.personaId, verhaeltnis: r.verhaeltnis ?? '' }));
        }
        setRelationAssignments(rels);
        if (d?.profilBildPath) {
          fetch(`/api/image/${d.id}`)
            .then((r) => r.json())
            .then((img) => setExistingImage(img?.url ?? null))
            .catch(() => {});
        }
      })
      .catch(() => toast.error('Fehler beim Laden'))
      .finally(() => setLoading(false));
  }, [personaId]);

  const parseGeburtstag = (val: string) => {
    if (!val) { setGebTag(''); setGebMonat(''); return; }
    const t = val.trim();
    const iso = t.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (iso) {
      const mo = parseInt(iso[2], 10);
      setGebTag(iso[3]);
      setGebMonat(mo >= 1 && mo <= 12 ? MONTH_NAMES[mo - 1] : '');
      return;
    }
    const m = t.match(/^(\d{1,2})\.\s*(.+)$/);
    if (m) {
      setGebTag(m[1].padStart(2, '0'));
      setGebMonat(m[2].trim());
    } else {
      setGebTag(''); setGebMonat('');
    }
  };

  const update = (key: keyof PersonaFormData) => (val: string) =>
    setForm((prev) => ({ ...prev, [key]: val }));

  const addFirmaAssignment = () =>
    setFirmaAssignments((prev) => [...prev, { firmaId: '', funktionInFirma: '' }]);
  const updateFirmaAssignment = (idx: number, patch: Partial<FirmaAssignment>) =>
    setFirmaAssignments((prev) => prev.map((a, i) => (i === idx ? { ...a, ...patch } : a)));
  const removeFirmaAssignment = (idx: number) =>
    setFirmaAssignments((prev) => prev.filter((_, i) => i !== idx));

  const addRelationAssignment = () =>
    setRelationAssignments((prev) => [...prev, { relatedPersonaId: '', verhaeltnis: '' }]);
  const updateRelationAssignment = (idx: number, patch: Partial<RelationAssignment>) =>
    setRelationAssignments((prev) => prev.map((a, i) => (i === idx ? { ...a, ...patch } : a)));
  const removeRelationAssignment = (idx: number) =>
    setRelationAssignments((prev) => prev.filter((_, i) => i !== idx));

  const onCropComplete = useCallback((_area: any, areaPixels: any) => {
    setCroppedAreaPixels(areaPixels);
  }, []);

  const handleFileSelected = (f: File) => {
    const url = URL.createObjectURL(f);
    setCropSrc(url);
    setCropName(f.name || 'bild.jpg');
    setCrop({ x: 0, y: 0 });
    setZoom(1);
    setCroppedAreaPixels(null);
  };

  const confirmCrop = async () => {
    if (!cropSrc || !croppedAreaPixels) { setCropSrc(null); return; }
    try {
      const blob = await getCroppedBlob(cropSrc, croppedAreaPixels);
      if (blob) {
        const baseName = cropName.replace(/\.[^.]+$/, '') || 'bild';
        const cropped = new File([blob], `${baseName}.jpg`, { type: 'image/jpeg' });
        setFile(cropped);
        setRemoveImage(false);
      }
    } catch {
      toast.error('Zuschnitt fehlgeschlagen');
    } finally {
      setCropSrc(null);
    }
  };

  const cancelCrop = () => setCropSrc(null);

  const clearImage = () => {
    setFile(null);
    setExistingImage(null);
    setRemoveImage(true);
  };

  const uploadImage = async (): Promise<{ path: string; isPublic: boolean } | null> => {
    if (!file) return null;
    try {
      const res = await fetch('/api/upload/presigned', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileName: file.name, contentType: file.type, isPublic: true }),
      });
      const { uploadUrl, cloud_storage_path } = await res.json();
      await fetch(uploadUrl, {
        method: 'PUT',
        headers: { 'Content-Type': file.type },
        body: file,
      });
      return { path: cloud_storage_path, isPublic: true };
    } catch {
      toast.error('Bild-Upload fehlgeschlagen');
      return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.vorname) {
      toast.error('Name und Vorname sind Pflichtfelder');
      return;
    }
    setSaving(true);

    try {
      const imageResult = await uploadImage();
      // Geburtstag aus Tag/Monat zusammensetzen ("TT. Monat")
      let geburtstag: string | null = null;
      if (gebTag && gebMonat) geburtstag = `${gebTag}. ${gebMonat}`;
      else if (gebMonat) geburtstag = gebMonat;
      else if (gebTag) geburtstag = `${gebTag}.`;

      const body: any = {
        ...form,
        geburtstag,
        alter: form.alter ? parseInt(form.alter) : null,
      };
      // Clear empty strings to null
      for (const key of Object.keys(body)) {
        if (body[key] === '') body[key] = null;
      }
      if (imageResult) {
        body.profilBildPath = imageResult.path;
        body.profilBildPublic = imageResult.isPublic;
      } else if (removeImage) {
        body.profilBildPath = null;
      }
      body.firmenAssignments = firmaAssignments
        .filter((a) => a.firmaId !== '' && a.firmaId != null)
        .map((a) => ({ firmaId: Number(a.firmaId), funktionInFirma: a.funktionInFirma || null }));
      body.relationAssignments = relationAssignments
        .filter((a) => a.relatedPersonaId !== '' && a.relatedPersonaId != null)
        .map((a) => ({ relatedPersonaId: Number(a.relatedPersonaId), verhaeltnis: a.verhaeltnis || null }));

      const url = isEdit ? `/api/personas/${personaId}` : '/api/personas';
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (res.ok) {
        const data = await res.json();
        toast.success(isEdit ? 'Persona aktualisiert' : 'Persona erstellt');
        router.push(`/personas/${data?.id ?? personaId}`);
      } else {
        const err = await res.json().catch(() => ({}));
        toast.error(err?.error ?? 'Fehler beim Speichern');
      }
    } catch {
      toast.error('Fehler beim Speichern');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-3 border-[#001957] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const previewSrc = file ? URL.createObjectURL(file) : existingImage;

  return (
    <form onSubmit={handleSubmit}>
      <div className="flex items-center justify-between mb-6">
        <Link
          href={isEdit ? `/personas/${personaId}` : '/personas'}
          className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-[#001957] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Zurück
        </Link>
        <button
          type="submit"
          disabled={saving}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
        >
          <Save className="w-4 h-4" />
          {saving ? 'Speichern…' : 'Speichern'}
        </button>
      </div>

      <h1 className="text-2xl font-bold text-[#001957] mb-6">
        {isEdit ? 'Persona bearbeiten' : 'Neue Persona'}
      </h1>

      {/* Image upload */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6 mb-6">
        <h2 className="text-sm font-bold text-[#001957] mb-3">Profilbild</h2>
        <div className="flex items-center gap-4">
          {previewSrc && (
            <div className="relative w-20 h-20 rounded-lg overflow-hidden bg-gray-100">
              <Image
                src={previewSrc}
                alt="Vorschau"
                fill
                className="object-cover"
              />
              <button
                type="button"
                onClick={clearImage}
                className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-0.5"
                aria-label="Bild entfernen"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          <div className="flex flex-col gap-2">
            <label className="inline-flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm text-[#001957] hover:bg-gray-50 cursor-pointer transition-colors">
              <Upload className="w-4 h-4" />
              {previewSrc ? 'Bild ändern' : 'Bild auswählen'}
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleFileSelected(f);
                  e.target.value = '';
                }}
              />
            </label>
            {previewSrc && (
              <button
                type="button"
                onClick={clearImage}
                className="inline-flex items-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-sm text-[#FF4C4C] hover:bg-red-50 transition-colors"
              >
                <X className="w-4 h-4" /> Bild löschen
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Form sections */}
      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] mb-4">Persönliche Daten</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Input label="Vorname *" value={form.vorname} onChange={update('vorname')} />
            <Input label="Name *" value={form.name} onChange={update('name')} />
            <SelectInput label="Geschlecht" value={form.geschlecht} onChange={update('geschlecht')} options={geschlechtOptions} />
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Geburtstag</label>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={gebTag}
                  onChange={(e) => setGebTag(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
                  aria-label="Tag"
                >
                  <option value="">Tag</option>
                  {tagOptions.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
                <select
                  value={gebMonat}
                  onChange={(e) => setGebMonat(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
                  aria-label="Monat"
                >
                  <option value="">Monat</option>
                  {MONTH_NAMES.map((m) => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
            </div>
            <Input label="Alter" value={form.alter} onChange={update('alter')} type="number" />
            <Input label="Herkunft" value={form.herkunft} onChange={update('herkunft')} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] mb-4">Kontakt & Wohnen</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Input label="Straße" value={form.strasse} onChange={update('strasse')} />
            <Input label="PLZ" value={form.plz} onChange={update('plz')} />
            <Input label="Ort" value={form.ort} onChange={update('ort')} />
            <Input label="Stadtteil" value={form.stadtteil} onChange={update('stadtteil')} />
            <Input label="Wohnart" value={form.wohnart} onChange={update('wohnart')} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] mb-4">Beruf & Rolle</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Input label="Funktion in der Lernwelt" value={form.funktion} onChange={update('funktion')} />
            <SelectInput label="Gruppe" value={form.gruppe} onChange={update('gruppe')} options={gruppeOptions} />
            <Input label="Beruf" value={form.beruf} onChange={update('beruf')} />
            <SelectInput label="Kundenprofil" value={form.kundenprofil} onChange={update('kundenprofil')} options={kundenprofilOptions} />
            <SelectInput label="Customer Journey" value={form.cJourney} onChange={update('cJourney')} options={cJourneyOptions} />
          </div>
        </div>

        {/* Firmenzuordnung */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-[#001957] flex items-center gap-2">
              <Building2 className="w-4 h-4" /> Firmenzuordnung
            </h2>
            <button
              type="button"
              onClick={addFirmaAssignment}
              className="inline-flex items-center gap-1 px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-medium text-[#001957] hover:bg-gray-50 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Firma hinzufügen
            </button>
          </div>
          {firmaAssignments.length === 0 ? (
            <p className="text-sm text-gray-400">Keine Firma zugeordnet.</p>
          ) : (
            <div className="space-y-3">
              {firmaAssignments.map((a, idx) => (
                <div key={idx} className="grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-3 items-end">
                  <div>
                    <label className="block text-xs font-medium text-gray-500 mb-1">Firma</label>
                    <select
                      value={a.firmaId === '' ? '' : String(a.firmaId)}
                      onChange={(e) => updateFirmaAssignment(idx, { firmaId: e.target.value ? Number(e.target.value) : '' })}
                      className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
                    >
                      <option value="">– Firma wählen –</option>
                      {allFirmen.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
                    </select>
                  </div>
                  <Input
                    label="Funktion in der Firma"
                    value={a.funktionInFirma}
                    onChange={(v) => updateFirmaAssignment(idx, { funktionInFirma: v })}
                  />
                  <button
                    type="button"
                    onClick={() => removeFirmaAssignment(idx)}
                    className="p-2 text-gray-400 hover:text-[#FF4C4C] transition-colors"
                    aria-label="Entfernen"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
          {allFirmen.length === 0 && (
            <p className="text-xs text-gray-400 mt-3">
              Noch keine Firmen vorhanden. Legen Sie zuerst unter „Firmen“ eine Firma an.
            </p>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] mb-4">Biografie & Persönlichkeit</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <SelectInput label="Familienstand" value={form.familienstand} onChange={update('familienstand')} options={familienstandOptions} />
            <TextArea label="Lebenslauf" value={form.lebenslauf} onChange={update('lebenslauf')} />
            <TextArea label="Aktivitäten" value={form.aktivitaeten} onChange={update('aktivitaeten')} />
            <TextArea label="Charakter" value={form.charakter} onChange={update('charakter')} />
            <TextArea label="Sonstiges" value={form.sonstiges} onChange={update('sonstiges')} />
          </div>

          {/* Familie – Verwandtschaften als Persona-Verknüpfung */}
          <div className="mt-6 pt-6 border-t border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-[#001957] flex items-center gap-2">
                <Users className="w-4 h-4" /> Familie
              </h3>
              <button
                type="button"
                onClick={addRelationAssignment}
                className="inline-flex items-center gap-1 px-3 py-1.5 border border-gray-200 rounded-lg text-xs font-medium text-[#001957] hover:bg-gray-50 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Verwandte/n hinzufügen
              </button>
            </div>
            {relationAssignments.length === 0 ? (
              <p className="text-sm text-gray-400">Keine Familienbeziehungen erfasst.</p>
            ) : (
              <div className="space-y-3">
                {relationAssignments.map((a, idx) => (
                  <div key={idx} className="grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-3 items-end">
                    <div>
                      <label className="block text-xs font-medium text-gray-500 mb-1">Person</label>
                      <select
                        value={a.relatedPersonaId === '' ? '' : String(a.relatedPersonaId)}
                        onChange={(e) => updateRelationAssignment(idx, { relatedPersonaId: e.target.value ? Number(e.target.value) : '' })}
                        className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
                      >
                        <option value="">– Persona wählen –</option>
                        {allPersonas
                          .filter((p) => !isEdit || String(p.id) !== String(personaId))
                          .map((p) => <option key={p.id} value={p.id}>{p.vorname} {p.name}</option>)}
                      </select>
                    </div>
                    <Input
                      label="Verwandtschaftsverhältnis"
                      value={a.verhaeltnis}
                      onChange={(v) => updateRelationAssignment(idx, { verhaeltnis: v })}
                    />
                    <button
                      type="button"
                      onClick={() => removeRelationAssignment(idx)}
                      className="p-2 text-gray-400 hover:text-[#FF4C4C] transition-colors"
                      aria-label="Entfernen"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
            {form.verwandt && form.verwandt.trim() && (
              <div className="mt-4">
                <TextArea label="Weitere Familienangaben (Freitext)" value={form.verwandt} onChange={update('verwandt')} />
              </div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] mb-4">Voiceover & Avatar</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Input label="WoC-Stimme" value={form.wocStimme} onChange={update('wocStimme')} />
            <Input label="DID-Avatar" value={form.didAvatar} onChange={update('didAvatar')} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] mb-4">Links & Medien</h2>
          <Input label="Bilder-Link" value={form.bilderLink} onChange={update('bilderLink')} />
        </div>
      </div>

      {/* Zuschnitt-Modal */}
      {cropSrc && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100 flex items-center gap-2">
              <CropIcon className="w-4 h-4 text-[#001957]" />
              <h3 className="text-base font-bold text-[#001957]">Bildausschnitt wählen</h3>
            </div>
            <div className="relative w-full h-72 bg-gray-900">
              <Cropper
                image={cropSrc}
                crop={crop}
                zoom={zoom}
                aspect={1}
                onCropChange={setCrop}
                onZoomChange={setZoom}
                onCropComplete={onCropComplete}
              />
            </div>
            <div className="px-6 py-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">Zoom</label>
                <input
                  type="range"
                  min={1}
                  max={3}
                  step={0.01}
                  value={zoom}
                  onChange={(e) => setZoom(Number(e.target.value))}
                  className="w-full accent-[#109DA8]"
                />
              </div>
              <div className="flex gap-3 justify-end">
                <button
                  type="button"
                  onClick={cancelCrop}
                  className="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium text-[#001957] hover:bg-gray-50 transition-colors"
                >
                  Abbrechen
                </button>
                <button
                  type="button"
                  onClick={confirmCrop}
                  className="px-4 py-2 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium transition-colors"
                >
                  Ausschnitt übernehmen
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </form>
  );
}
