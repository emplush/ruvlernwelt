import { verifyAuth } from '@/lib/auth';
import { redirect } from 'next/navigation';

export default async function AuthGuard({ children }: { children: React.ReactNode }) {
  const isAuth = await verifyAuth();
  if (!isAuth) redirect('/login');
  return <>{children}</>;
}
