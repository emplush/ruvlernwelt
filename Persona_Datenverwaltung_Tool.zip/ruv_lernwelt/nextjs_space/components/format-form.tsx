'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Save, Search, Check } from 'lucide-react';
import { toast } from 'sonner';

interface Persona {
  id: number; vorname: string; name: string; funktion: string | null;
}

export default function FormatForm({ formatId }: { formatId?: string }) {
  const [name, setName] = useState('');
  const [formatNr, setFormatNr] = useState('');
  const [link, setLink] = useState('');
  const [httpLink, setHttpLink] = useState('');
  const [formatTyp, setFormatTyp] = useState('Lernprogramm');
  const [medienentwickler, setMedienentwickler] = useState('');
  const [selectedPersonaIds, setSelectedPersonaIds] = useState<number[]>([]);
  const [allPersonas, setAllPersonas] = useState<Persona[]>([]);
  const [personaSearch, setPersonaSearch] = useState('');
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const isEdit = !!formatId;

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const pRes = await fetch('/api/personas');
        const pData = await pRes.json();
        setAllPersonas(Array.isArray(pData) ? pData : []);

        if (formatId) {
          const fRes = await fetch(`/api/formate/${formatId}`);
          const fData = await fRes.json();
          setName(fData?.name ?? '');
          setFormatNr(fData?.formatId != null ? String(fData.formatId) : '');
          setLink(fData?.link ?? '');
          setHttpLink(fData?.httpLink ?? '');
          setFormatTyp(fData?.formatTyp ?? 'Lernprogramm');
          setMedienentwickler(fData?.medienentwickler ?? '');
          setSelectedPersonaIds((fData?.personas ?? []).map((fp: any) => fp?.persona?.id).filter(Boolean));
        }
      } catch {
        toast.error('Fehler beim Laden');
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, [formatId]);

  const togglePersona = (pid: number) => {
    setSelectedPersonaIds((prev) =>
      prev.includes(pid) ? prev.filter((i) => i !== pid) : [...prev, pid]
    );
  };

  const filteredPersonas = (allPersonas ?? []).filter((p) => {
    if (!personaSearch) return true;
    const q = personaSearch.toLowerCase();
    return `${p.vorname} ${p.name}`.toLowerCase().includes(q) ||
      (p.funktion ?? '').toLowerCase().includes(q);
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { toast.error('Name ist ein Pflichtfeld'); return; }
    if (!medienentwickler.trim()) { toast.error('Medienentwickler ist ein Pflichtfeld'); return; }

    setSaving(true);
    try {
      const body = { name, formatId: formatNr, link, httpLink, formatTyp, medienentwickler, personaIds: selectedPersonaIds };
      const url = isEdit ? `/api/formate/${formatId}` : '/api/formate';
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (res.ok) {
        const data = await res.json();
        toast.success(isEdit ? 'Format aktualisiert' : 'Format erstellt');
        router.push(`/formate/${data?.id ?? formatId}`);
      } else {
        const err = await res.json().catch(() => ({}));
        toast.error(err?.error ?? 'Fehler');
      }
    } catch {
      toast.error('Fehler beim Speichern');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center py-20"><div className="w-8 h-8 border-3 border-[#001957] border-t-transparent rounded-full animate-spin" /></div>;
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="flex items-center justify-between mb-6">
        <Link href={isEdit ? `/formate/${formatId}` : '/formate'} className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-[#001957]">
          <ArrowLeft className="w-4 h-4" /> Zurück
        </Link>
        <button type="submit" disabled={saving} className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#001957] hover:bg-[#00113f] text-white rounded-lg text-sm font-medium disabled:opacity-50">
          <Save className="w-4 h-4" /> {saving ? 'Speichern…' : 'Speichern'}
        </button>
      </div>

      <h1 className="text-2xl font-bold text-[#001957] mb-6">{isEdit ? 'Format bearbeiten' : 'Neues Format'}</h1>

      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] mb-4">Formatdaten</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Name *</label>
              <input value={name} onChange={(e) => setName(e.target.value)} className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Format-Typ *</label>
              <select value={formatTyp} onChange={(e) => setFormatTyp(e.target.value)} className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30">
                <option value="Lernprogramm">Lernprogramm</option>
                <option value="Video">Video</option>
                <option value="Podcast">Podcast</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">ID</label>
              <input type="number" min={0} max={999} value={formatNr} onChange={(e) => setFormatNr(e.target.value)} placeholder="3-stellige Nummer" className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30" />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">Datei-Link</label>
              <input value={link} onChange={(e) => setLink(e.target.value)} placeholder="\\Server\Freigabe\Ordner oder C:\Ordner" className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30" />
              <p className="text-[11px] text-gray-400 mt-1">Pfad auf Dateiebene, der im Windows-Explorer geöffnet wird.</p>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-500 mb-1">HTTP-Link</label>
              <input value={httpLink} onChange={(e) => setHttpLink(e.target.value)} placeholder="https://..." className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30" />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-gray-500 mb-1">Medienentwickler *</label>
              <input value={medienentwickler} onChange={(e) => setMedienentwickler(e.target.value)} className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <h2 className="text-sm font-bold text-[#001957] mb-4">Personas zuweisen ({selectedPersonaIds.length} ausgewählt)</h2>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Persona suchen…"
              value={personaSearch}
              onChange={(e) => setPersonaSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-[#001957] focus:outline-none focus:ring-2 focus:ring-[#001957]/30"
            />
          </div>
          <div className="max-h-64 overflow-y-auto space-y-1">
            {filteredPersonas.map((p) => {
              const selected = selectedPersonaIds.includes(p.id);
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => togglePersona(p.id)}
                  className={`w-full text-left flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                    selected ? 'bg-[#001957]/10 text-[#001957]' : 'hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded border flex items-center justify-center flex-shrink-0 ${
                    selected ? 'bg-[#001957] border-[#001957]' : 'border-gray-300'
                  }`}>
                    {selected && <Check className="w-3 h-3 text-white" />}
                  </div>
                  <span className="font-medium">{p.vorname} {p.name}</span>
                  {p.funktion && <span className="text-gray-400 text-xs">{p.funktion}</span>}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </form>
  );
}
