import { PrismaClient } from "@prisma/client";
import fs from "fs";
import path from "path";

const prisma = new PrismaClient();

function cleanFloat(val: any): number | null {
  if (val === null || val === undefined || val === "") return null;
  const n = parseFloat(String(val));
  return isNaN(n) ? null : Math.round(n);
}

function cleanStr(val: any): string | null {
  if (val === null || val === undefined) return null;
  const s = String(val).trim();
  return s === "" ? null : s;
}

function normalizeGruppe(val: any): string | null {
  const s = cleanStr(val);
  if (!s) return null;
  const map: Record<string, string> = {
    "Kunde - Privat": "Privatkunde",
    "Kunde - Firma": "Firmenkunde",
    "Kunde-Firma": "Firmenkunde",
    "Bank - Mitarbeiter": "Bankmitarbeitende/r",
    "R+V - Außendienst": "R+V Außendienst",
    "R+V - Wiesbaden": "R+V Innendienst",
    "Extern": "Extern",
  };
  return map[s] ?? s;
}

function normalizeGeschlecht(val: any): string | null {
  const s = cleanStr(val);
  if (!s || s === "-") return null;
  const l = s.toLowerCase();
  if (l === "m" || l === "männlich") return "männlich";
  if (l === "f" || l === "w" || l === "weiblich") return "weiblich";
  if (l === "d" || l === "divers") return "divers";
  return s;
}

function normalizeFamilienstand(val: any): string | null {
  const s = cleanStr(val);
  if (!s || s === "---") return "keine Angabe";
  const l = s.toLowerCase();
  if (l === "verheiratet") return "verheiratet";
  if (l === "ledig" || l === "single") return "ledig / Single";
  if (l === "in beziehung") return "ledig / in Beziehung";
  if (l === "geschieden") return "geschieden";
  if (l === "verwitwet") return "verwitwet";
  return s;
}

const MONTH_NAMES: Record<string, string> = {
  januar: "Januar", februar: "Februar", märz: "März", april: "April", mai: "Mai", juni: "Juni",
  juli: "Juli", august: "August", september: "September", oktober: "Oktober", november: "November", dezember: "Dezember",
};

// Geburtstag stored as "TT. Monat" (Tag zweistellig, Monatsname) – kein Jahr
function normalizeGeburtstag(val: any): string | null {
  const s = cleanStr(val);
  if (!s || s === "---") return null;
  const m = s.match(/^(\d{1,2})\.\s*([A-Za-zäöüÄÖÜ]+)$/);
  if (!m) return null;
  const day = m[1].padStart(2, "0");
  const month = MONTH_NAMES[m[2].toLowerCase()];
  if (!month) return null;
  return `${day}. ${month}`;
}

const KUNDENPROFIL_ALLOWED = ["Durchstarter", "Karriereeltern", "Weltoffene", "Aktive", "Lebensentdecker", "Familienmenschen", "Traditionelle", "Besonnene"];
function normalizeKundenprofil(val: any): string {
  const s = cleanStr(val);
  if (!s) return "keine Angabe";
  const first = s.split(/\r?\n/)[0].trim();
  let cand = first;
  const idx = first.lastIndexOf(" - ");
  if (idx >= 0) cand = first.slice(idx + 3).trim();
  return KUNDENPROFIL_ALLOWED.includes(cand) ? cand : "keine Angabe";
}

function cleanBilderLink(val: any): string | null {
  const s = cleanStr(val);
  if (!s) return null;
  return s.replace(/^#/, "").replace(/#$/, "");
}

async function main() {
  // Only seed if no personas exist
  const count = await prisma.persona.count();
  if (count > 0) {
    console.log(`Skipping seed: ${count} personas already exist.`);
    return;
  }

  // Seed settings
  await prisma.settings.upsert({
    where: { id: 1 },
    update: {},
    create: {
      id: 1,
      appTitle: "R+V Lernwelt \u2013 Persona-Datenbank",
      password: "RuVTest1234",
    },
  });

  // Load JSON
  const dataPath = path.join(__dirname, "..", "data", "lernwelt_data.json");
  const raw = fs.readFileSync(dataPath, "utf-8");
  const data: any[] = JSON.parse(raw);

  console.log(`Importing ${data.length} personas...`);

  for (const row of data) {
    const personaId = cleanFloat(row["ID"]);
    await prisma.persona.create({
      data: {
        personaId,
        name: cleanStr(row["Name"]) ?? "Unbekannt",
        vorname: cleanStr(row["Vorname"]) ?? "Unbekannt",
        gruppe: normalizeGruppe(row["Gruppe"]),
        funktion: cleanStr(row["Funktion"]),
        kundenprofil: normalizeKundenprofil(row["Kundenprofil"]),
        cJourney: cleanStr(row["C-Journey"]),
        geschlecht: normalizeGeschlecht(row["Geschlecht"]),
        herkunft: cleanStr(row["Herkunft"]),
        geburtstag: normalizeGeburtstag(row["Geburtstag"]),
        alter: cleanFloat(row["Alter"]),
        strasse: cleanStr(row["Stra\u00dfe"]),
        plz: cleanStr(row["PLZ"]) ? String(cleanFloat(row["PLZ"])) : null,
        ort: cleanStr(row["Ort"]),
        stadtteil: cleanStr(row["Stadtteil"]),
        beruf: cleanStr(row["Beruf"]),
        familienstand: normalizeFamilienstand(row["Familienstand"]),
        wohnart: cleanStr(row["Wohnart"]),
        verwandt: cleanStr(row["Verwandt"]),
        lebenslauf: cleanStr(row["Lebenslauf"]),
        aktivitaeten: cleanStr(row["Aktivit\u00e4ten"]),
        charakter: cleanStr(row["Charakter"]),
        sonstiges: cleanStr(row["Sonstiges"]),
        wocStimme: cleanStr(row["WoC-Stimme"]),
        didAvatar: cleanStr(row["DID-Avatar"]),
        bilderLink: cleanBilderLink(row["Bilder-Link"]),
        profilBildPath: null,
        profilBildPublic: true,
      },
    });
  }

  console.log(`Successfully imported ${data.length} personas.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
