import com.healthmarketscience.jackcess.*;
import java.io.File;
import java.util.*;

public class ReadAccdb {
    public static void main(String[] args) throws Exception {
        Database db = DatabaseBuilder.open(new File("/home/ubuntu/Uploads/Lernwelt_Test.accdb"));
        Set<String> tableNames = db.getTableNames();
        System.out.println("TABLES:");
        for (String name : tableNames) {
            System.out.println("  " + name);
        }
        
        for (String tableName : tableNames) {
            if (tableName.startsWith("~") || tableName.startsWith("MSys")) continue;
            Table table = db.getTable(tableName);
            System.out.println("\nTABLE: " + tableName);
            System.out.println("COLUMNS: " + table.getColumns().stream()
                .map(c -> c.getName() + "(" + c.getType() + ")")
                .collect(java.util.stream.Collectors.joining(", ")));
            
            // Print first 3 rows
            int count = 0;
            for (Row row : table) {
                if (count++ >= 3) break;
                System.out.println("  ROW: " + row);
            }
        }
        db.close();
    }
}
